// Dominó Dominicano · cuentas, sesiones y monedas
import { randomBytes, randomInt, scryptSync, timingSafeEqual, createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { call, now } from './store/index.js';
import { CFG } from './config.js';
import { hasBad } from './moderation.js';
import { sendCode } from './mail.js';

const require = createRequire(import.meta.url);
export const P = require('../shared/profile.js');

const sha = (s) => createHash('sha256').update(s).digest('hex');
const hashPass = (pw, salt) => scryptSync(pw, salt, 32, { N: 16384, r: 8, p: 1 }).toString('hex');
const tidy = (name) => String(name).trim().replace(/\s+/g, ' ');
const lc = (name) => tidy(name).toLowerCase();

export const getUser = (id) => call('user_get', { id });
export const userByName = (name) => call('user_by_name', { name_lc: lc(name || '') });

// Lo que el jugador ve de su propia cuenta
export function publicMe(u) {
  return {
    id: u.id, name: u.name, avatar: u.avatar, coins: u.coins, registered: !!u.registered, email: u.email || null,
    prefs: P.cleanPrefs(safeJson(u.prefs), owned(u)), owned: owned(u), games: u.games, wins: u.wins, coinsWon: u.coins_won,
    daily: dailyAvailable(u), rescue: rescueAvailable(u), muted: u.muted_until > now() ? u.muted_until : 0
  };
}
export const publicUser = (u) => ({ id: u.id, name: u.name, avatar: u.avatar });
export function owned(u) { try { const o = typeof u.owned === 'string' ? JSON.parse(u.owned || '[]') : u.owned; return Array.isArray(o) ? o : []; } catch { return []; } }
function safeJson(s) { if (s && typeof s === 'object') return s; try { return JSON.parse(s || '{}'); } catch { return {}; } }

export async function newSession(userId) {
  const token = randomBytes(32).toString('hex');
  await call('session_create', { hash: sha(token), uid: userId, now: now() });
  return token;
}
export async function userFromToken(token) {
  if (typeof token !== 'string' || !/^[0-9a-f]{64}$/.test(token)) return null;
  return call('session_user', { hash: sha(token), now: now() });
}
export const endSession = (token) => (typeof token === 'string' ? call('session_delete', { hash: sha(token) }) : null);

// Cuenta de invitado: entra al momento, con monedas de bienvenida. Luego puede ponerle contraseña.
export async function createGuest() {
  for (let i = 0; i < 40; i++) {
    const name = i < 30 ? 'Jugador' + (1000 + Math.floor(Math.random() * 9000)) : 'Jugador' + Date.now().toString(36) + i;
    const u = await call('guest_create', { name, name_lc: name.toLowerCase(), avatar: P.random(), prefs: JSON.stringify(P.DEFAULT_PREFS), coins: CFG.START_COINS, now: now() });
    if (u) return u;
  }
  throw new Error('No se pudo crear la cuenta de invitado');
}

export async function nameError(name, selfId) {
  const e = P.checkName(name); if (e) return e;
  const n = tidy(name);
  if (hasBad(n)) return 'Ese nombre no está permitido';
  const other = await call('user_by_name', { name_lc: n.toLowerCase() });
  if (other && other.id !== selfId) return 'Ese nombre ya lo tiene otra persona';
  return null;
}
const TAKEN = { error: 'Ese nombre ya lo tiene otra persona' };

const EMAIL_RE = /^[^\s@]{1,64}@[^\s@]{1,190}\.[a-z]{2,24}$/i;
const lastSent = new Map(); // id → hora del último código (no más de uno por minuto)

// Paso 1 del registro: nombre, correo y contraseña → se envía un código de 6 números al correo
export async function register(user, name, email, password, adult) {
  const e = await nameError(name, user.id); if (e) return { error: e };
  if (adult !== true) return { error: 'Debes tener 18 años o más para registrarte.' };
  email = String(email || '').trim().toLowerCase();
  if (!EMAIL_RE.test(email)) return { error: 'Escribe un correo válido' };
  if (typeof password !== 'string' || password.length < 6) return { error: 'La contraseña debe tener al menos 6 caracteres' };
  if (password.length > 100) return { error: 'La contraseña es demasiado larga' };
  const other = await call('user_by_email', { email });
  if (other && other.id !== user.id) return { error: 'Ese correo ya tiene una cuenta. Entra con él.' };
  const n = tidy(name), salt = randomBytes(16).toString('hex');
  return sendNewCode(user, email, { name: n, name_lc: n.toLowerCase(), pass: hashPass(password, salt), salt });
}
async function sendNewCode(user, email, payload) {
  if (now() - (lastSent.get(user.id) || 0) < 60e3) return { error: 'Espera un minuto para pedir otro código.' };
  const code = String(randomInt(0, 1e6)).padStart(6, '0');
  await call('email_code_set', { uid: user.id, email, payload: payload || null, code_hash: sha(user.id + ':' + code), expires: now() + CFG.EMAIL_CODE_MIN * 60e3, now: now() });
  lastSent.set(user.id, now());
  const sent = await sendCode(email, code, payload ? payload.name : user.name);
  if (!sent.ok) return { error: 'No pudimos enviar el correo. Revisa la dirección e intenta otra vez.' };
  return { pending: true, email };
}
export async function resendCode(user) {
  const p = await call('email_code_get', { uid: user.id });
  if (!p) return { error: 'Primero escribe tus datos para registrarte.' };
  return sendNewCode(user, p.email, p.payload);
}
// Paso 2: el código que llegó al correo → la cuenta queda registrada y verificada
export async function verify(user, code) {
  code = String(code || '').replace(/\D/g, '');
  if (code.length !== 6) return { error: 'El código tiene 6 números' };
  const r = await call('email_code_check', { uid: user.id, code_hash: sha(user.id + ':' + code), now: now() });
  if (r.error) return { error: { vencido: 'El código venció. Pide otro.', intentos: 'Demasiados intentos. Pide otro código.', ninguno: 'Primero escribe tus datos para registrarte.' }[r.error] || 'Código incorrecto' };
  const p = r.payload || {};
  const u = await call('user_register', { id: user.id, name: p.name || user.name, name_lc: p.name_lc || lc(user.name), pass: p.pass || user.pass, salt: p.salt || user.salt, email: r.email });
  if (u.error === 'correo') return { error: 'Ese correo ya tiene una cuenta. Entra con él.' };
  return u.error ? TAKEN : { user: u.user };
}

export async function login(name, password) {
  const id = String(name || '').trim();
  const u = id.includes('@') ? await call('user_by_email', { email: id.toLowerCase() }) : await userByName(id);
  if (!u || !u.pass || typeof password !== 'string') return { error: 'Nombre o contraseña incorrectos' };
  const a = Buffer.from(hashPass(password, u.salt), 'hex'), b = Buffer.from(u.pass, 'hex');
  if (a.length !== b.length || !timingSafeEqual(a, b)) return { error: 'Nombre o contraseña incorrectos' };
  if (u.banned) return { error: 'Esta cuenta está suspendida' + (u.ban_reason ? ': ' + u.ban_reason : '') };
  return { user: u, token: await newSession(u.id) };
}

export async function updateProfile(user, body) {
  const out = { id: user.id };
  if (body.name != null && body.name !== user.name) {
    const e = await nameError(body.name, user.id); if (e) return { error: e };
    out.name = tidy(body.name); out.name_lc = out.name.toLowerCase();
  }
  if (body.avatar != null) { if (!P.valid(body.avatar)) return { error: 'Avatar inválido' }; out.avatar = body.avatar; }
  if (body.prefs != null) out.prefs = JSON.stringify(P.cleanPrefs(body.prefs, owned(user)));
  const r = await call('user_update', out);
  return r.error ? TAKEN : { user: r.user };
}

// ---- bonos ----
const dayNum = (t = now()) => Math.floor((t + CFG.TZ_OFFSET_H * 3600e3) / 86400e3);
export const dailyAvailable = (u) => CFG.DAILY_COINS > 0 && u.daily_day < dayNum();
export const rescueAvailable = (u) => CFG.RESCUE_COINS > 0 && u.coins < Math.min(...CFG.STAKES) && now() - u.rescue_at >= CFG.RESCUE_EVERY_H * 3600e3;
export async function claimDaily(u) {
  const coins = dailyAvailable(u) ? await call('claim_daily', { id: u.id, day: dayNum(), amount: CFG.DAILY_COINS, now: now() }) : null;
  if (coins == null) return { error: 'Ya cobraste el bono de hoy. Vuelve mañana.' };
  return { coins, amount: CFG.DAILY_COINS };
}
export async function claimRescue(u) {
  const coins = rescueAvailable(u) ? await call('claim_rescue', { id: u.id, now: now(), amount: CFG.RESCUE_COINS, every_ms: CFG.RESCUE_EVERY_H * 3600e3, min_stake: Math.min(...CFG.STAKES) }) : null;
  if (coins == null) return { error: 'El bono de rescate es para cuando te quedas sin saldo, una vez cada ' + CFG.RESCUE_EVERY_H + ' horas.' };
  return { coins, amount: CFG.RESCUE_COINS };
}

export const leaderboard = (by) => call('leaderboard', { by: by === 'money' ? 'money' : 'wins' });
export const history = (u) => call('history', { uid: u.id });
export const moveCoins = (uid, delta, reason, ref = null) => call('move_coins', { uid, delta: Math.trunc(delta), reason, ref, now: now() });
