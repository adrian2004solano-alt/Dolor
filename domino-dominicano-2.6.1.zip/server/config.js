// Dominó Dominicano · configuración del servidor
// Todo se puede cambiar con variables de entorno (en Railway/Render: pestaña "Variables").
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

const ROOT = join(fileURLToPath(new URL('.', import.meta.url)), '..');
const num = (v, d) => (v != null && v !== '' && !isNaN(+v) ? +v : d);

export const CFG = {
  ROOT,
  PORT: num(process.env.PORT, 3000),
  DATA_DIR: process.env.DATA_DIR || join(ROOT, 'data'),       // solo con SQLite: dónde se guarda domino.db (con Supabase no se usa)
  ADMIN_KEY: process.env.ADMIN_KEY || '',                       // clave del panel de administración (/admin). Sin clave, el panel está apagado
  ALLOWED_ORIGINS: (process.env.ALLOWED_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean), // si el sitio está en otro dominio
  TRUST_PROXY: process.env.TRUST_PROXY !== '0',                 // detrás de Railway/Render/Fly la IP real viene en X-Forwarded-For

  // saldo en DÓLARES, guardado en CENTAVOS (1000 = $10.00). Es dinero real: no hay regalos automáticos.
  START_COINS: num(process.env.START_COINS, 0),                 // saldo de bienvenida (0)
  DAILY_COINS: num(process.env.DAILY_COINS, 0),                 // bono diario (0 = apagado)
  RESCUE_COINS: num(process.env.RESCUE_COINS, 0),               // bono de rescate (0 = apagado)
  RESCUE_EVERY_H: num(process.env.RESCUE_EVERY_H, 6),           // …cada cuántas horas
  STAKES: (process.env.STAKES || '1000,2000,4000,8000').split(',').map(Number), // montos en centavos: $10, $20, $40, $80 (y 0 = gratis)
  MONEY_BOTS: process.env.MONEY_BOTS === '1',                   // ¿completar mesas CON DINERO con la computadora? (no por defecto)
  MONEY_NEEDS_ACCOUNT: process.env.MONEY_NEEDS_ACCOUNT !== '0',
  PLAY_NEEDS_ACCOUNT: process.env.PLAY_NEEDS_ACCOUNT !== '0',   // para jugar (aunque sea gratis) hay que registrarse; mirar es libre // para jugar con dinero hay que estar registrado (correo verificado, 18+)
  PLATFORM_FEE: num(process.env.PLATFORM_FEE, 0.10),            // comisión de la plataforma por partida (10% de lo que juega cada uno)
  TZ_OFFSET_H: num(process.env.TZ_OFFSET_H, -4),                // día del bono diario (hora de República Dominicana)

  // mesas
  QUEUE_WAIT_MS: num(process.env.QUEUE_WAIT_MS, 12000),         // si no aparecen personas en este tiempo, se completa con la computadora
  GUEST_PER_HOUR: num(process.env.GUEST_PER_HOUR, 30),           // cuentas de invitado nuevas por hora desde una misma conexión
  TIME_SCALE: num(process.env.TIME_SCALE, 1),                   // solo para pruebas: acelera los tiempos de la mesa

  // billetera (recargas y retiros los aprueba el admin desde /admin)
  PAY_METHODS: (process.env.PAY_METHODS || 'Transferencia bancaria,PayPal').split(',').map((s) => s.trim()).filter(Boolean),
  PAY_INSTRUCTIONS: process.env.PAY_INSTRUCTIONS || 'Haz la transferencia o el pago y escribe aquí el número de referencia. Te acreditamos el saldo cuando lo confirmemos.',
  DEPOSIT_MIN: num(process.env.DEPOSIT_MIN, 500), DEPOSIT_MAX: num(process.env.DEPOSIT_MAX, 50000),     // $5 – $500
  WITHDRAW_MIN: num(process.env.WITHDRAW_MIN, 1000), WITHDRAW_MAX: num(process.env.WITHDRAW_MAX, 100000), // $10 – $1,000
  APK_URL: process.env.APK_URL || '',                           // enlace del archivo .apk (ej. /descargas/domino.apk)

  // salas privadas (invitación por enlace o código)
  SALA_CODE_LEN: 6,                                             // largo del código (ej. K7M2QX)
  SALA_PER_10MIN: num(process.env.SALA_PER_10MIN, 10),          // salas nuevas por persona cada 10 minutos
  SALA_OFFLINE_MS: num(process.env.SALA_OFFLINE_MS, 90000),     // si alguien se desconecta en la sala de espera, se libera su asiento
  SALA_IDLE_MS: num(process.env.SALA_IDLE_MS, 30 * 60000),      // una sala sin movimiento se cierra sola
  SALA_SOLO: process.env.SALA_SOLO === '1',                     // permitir empezar una sala con una sola persona (completa con BOT)

  // registro con correo
  RESEND_API_KEY: process.env.RESEND_API_KEY || '',             // para enviar el código por correo (Resend)
  MAIL_FROM: process.env.MAIL_FROM || 'Dominó Dominicano <onboarding@resend.dev>',
  EMAIL_CODE_MIN: num(process.env.EMAIL_CODE_MIN, 15),          // minutos que dura el código

  // chat
  CHAT_MAX: 200, CHAT_HISTORY: 60, CHAT_RATE: [5, 10000],       // máx. 5 mensajes cada 10 s
};
