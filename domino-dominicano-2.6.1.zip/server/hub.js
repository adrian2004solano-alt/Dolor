// Dominó Dominicano · centro del juego en línea
// Conexiones en tiempo real, quién está en línea, chat del lobby/sala/mesa, búsqueda de mesa (emparejamiento),
// salas privadas por invitación (enlace o código), mesas en juego, cobro de la apuesta y pago del premio.
//
// Lo que pasa EN VIVO (quién está conectado, las colas, las salas y las mesas) vive en la memoria de este proceso:
// por eso el servidor debe correr como UNA sola instancia. Lo que debe durar (cuentas, monedas, historial, chat,
// soporte, partidas) se guarda en la base de datos (Supabase o SQLite) a través de store/.
import { createRequire } from 'node:module';
import { randomBytes, randomInt } from 'node:crypto';
import { accept, heartbeat } from './ws.js';
import { call, now } from './store/index.js';
import { CFG } from './config.js';
import { clean, limiter } from './moderation.js';
import { userFromToken, getUser, publicMe, P } from './users.js';

const require = createRequire(import.meta.url);
const E = require('../shared/engine.js');
const Room = require('../shared/room.js');

const BOT_NAMES = ['Ramón', 'Mayra', 'Felo', 'Yohanna', 'Nelson', 'Chichí', 'Wandy', 'Dulce', 'Papo', 'Luisa', 'Kelvin', 'Yuly', 'Tony', 'Nena', 'Fello', 'Mingo', 'Cuca', 'Bienve'];
const TGT = (v) => (E.TARGETS.includes(+v) ? +v : 200);
const STAKE_OK = (v) => +v === 0 || CFG.STAKES.includes(+v); // 0 = partida gratis (sin monedas)
export const prizeFor = (stake, mode) => Math.floor(stake * E.numTeams(mode) * (1 - CFG.PLATFORM_FEE)); // el pozo menos la comisión
const CODE_ABC = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // sin 0/O ni 1/I para que no se confundan al dictarlo
export const normCode = (s) => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);

export class Hub {
  constructor() {
    this.socks = new Set();           // conexiones abiertas
    this.byUser = new Map();          // id de usuario → conexiones
    this.users = new Map();           // id de usuario → su fila (copia en memoria de los que están conectados)
    this.queues = new Map();          // 'modo|monto|meta' → [{ uid, since }]
    this.starting = new Set();        // usuarios a los que se les está creando una mesa ahora mismo
    this.rooms = new Map();           // id de mesa → { room, mode, stake, seats:[uid|null], sala }
    this.userRoom = new Map();        // id de usuario → { id, seat }
    this.salas = new Map();           // código → sala privada
    this.userSala = new Map();        // id de usuario → código de su sala
    this.chatOk = limiter(CFG.CHAT_RATE[0], CFG.CHAT_RATE[1]);
    this.tableOk = limiter(6, 10000);
    this.reportOk = limiter(5, 600000);
    this.salaNewOk = limiter(CFG.SALA_PER_10MIN, 600000);
    this.salaJoinOk = limiter(20, 60000);
    this.presenceDirty = true;
    this.timers = [];
  }
  async init() {
    try { const n = await call('match_void_active', { now: now() }); if (n) console.log(`Devueltas las apuestas de ${n} partida(s) interrumpida(s).`); }
    catch (e) { console.error('No se pudo revisar partidas interrumpidas:', e.message); throw e; }
    this.timers = [setInterval(() => this.tick(), 1000), heartbeat(this.socks)];
  }

  // ---- conexiones ----
  upgrade(req, sock, ip) {
    const origin = req.headers.origin;
    if (origin && !this.originOk(origin, req.headers.host)) { sock.end('HTTP/1.1 403 Forbidden\r\n\r\n'); return; }
    const ws = accept(req, sock); if (!ws) return;
    const conn = { ws, user: null, ip, at: now() };
    this.socks.add(ws);
    ws.on('message', (m) => { this.onMsg(conn, m).catch((e) => { console.error('ws', e); try { this.send(conn, { t: 'error', msg: 'Algo salió mal. Intenta otra vez.' }); } catch { /* cerrada */ } }); });
    ws.on('close', () => this.onClose(conn));
    conn.authTimer = setTimeout(() => { if (!conn.user) ws.close(4001); }, 10000);
  }
  originOk(origin, host) {
    try { const o = new URL(origin); if (o.host === host) return true; } catch { return false; }
    return CFG.ALLOWED_ORIGINS.includes(origin);
  }
  send(conn, msg) { conn.ws.send(msg); }
  sendUser(uid, msg) { const set = this.byUser.get(uid); if (!set) return; const s = JSON.stringify(msg); for (const c of set) c.ws.send(s); }
  broadcast(msg) { const s = JSON.stringify(msg); for (const set of this.byUser.values()) for (const c of set) c.ws.send(s); }
  online(uid) { return this.byUser.has(uid); }

  // copia en memoria de los usuarios conectados (así jugar no espera a la base de datos)
  setUser(u) { if (!u) return; if (this.byUser.has(u.id)) { this.users.set(u.id, u); for (const c of this.byUser.get(u.id)) c.user = u; } }
  async refreshUser(uid) { if (!this.online(uid)) return null; const u = await getUser(uid); this.setUser(u); return u; }
  user(uid) { return this.users.get(uid) || null; }

  onClose(conn) {
    this.socks.delete(conn.ws); clearTimeout(conn.authTimer);
    if (!conn.user) return;
    const uid = conn.user.id, set = this.byUser.get(uid);
    if (!set) return;
    set.delete(conn);
    if (set.size) return;
    this.byUser.delete(uid); this.users.delete(uid); this.unqueue(uid); this.presenceDirty = true;
    const ur = this.userRoom.get(uid); if (ur) { const R = this.rooms.get(ur.id); if (R) R.room.setConnected(ur.seat, false); }
    const S = this.salaOf(uid);
    if (S && S.state === 'espera') {
      this.salaPush(S);
      // si no vuelve pronto, deja libre su asiento
      setTimeout(() => { if (!this.online(uid) && this.userSala.get(uid) === S.code && S.state === 'espera') this.salaRemove(S, uid, 'desconectado'); }, CFG.SALA_OFFLINE_MS);
    }
  }

  async onMsg(conn, raw) {
    let m; try { m = JSON.parse(raw); } catch { return; }
    if (!m || typeof m.t !== 'string') return;
    if (!conn.user) { if (m.t === 'hello' && !conn.helloing) { conn.helloing = true; await this.hello(conn, m); conn.helloing = false; } return; }
    const user = this.user(conn.user.id) || conn.user;
    if (user.banned) { conn.ws.close(4003); return; }
    switch (m.t) {
      case 'chat': return this.chat(conn, user, m);
      case 'report': return this.report(conn, user, m);
      case 'queue': return this.queue(conn, user, m);
      case 'unqueue': this.unqueue(user.id); return this.send(conn, { t: 'unqueued' });
      case 'act': return this.act(conn, user, m);
      case 'leave': return this.leave(conn, user);
      case 'resume': return this.resume(conn, user);
      case 'me': return this.send(conn, { t: 'me', me: publicMe(user) });
      case 'ping': return this.send(conn, { t: 'pong' });
      case 'sala_crear': return this.salaCreate(conn, user, m);
      case 'sala_unirse': return this.salaJoin(conn, user, m);
      case 'sala_salir': { const S = this.salaOf(user.id); if (S) this.salaRemove(S, user.id, 'salio'); return this.send(conn, { t: 'sala', sala: null }); }
      case 'sala_asiento': return this.salaSeat(conn, user, m);
      case 'sala_config': return this.salaConfig(conn, user, m);
      case 'sala_expulsar': return this.salaKick(conn, user, m);
      case 'sala_iniciar': return this.salaStart(conn, user);
    }
  }

  async hello(conn, m) {
    let user;
    try { user = await userFromToken(m.token); } catch (e) { console.error('hello', e.message); this.send(conn, { t: 'error', msg: 'El servidor no pudo leer tu cuenta. Reintentando…' }); conn.ws.close(1011); return; }
    if (!user) { this.send(conn, { t: 'auth', ok: false }); conn.ws.close(4001); return; }
    if (user.banned) { this.send(conn, { t: 'banned', reason: user.ban_reason || '' }); conn.ws.close(4003); return; }
    clearTimeout(conn.authTimer);
    conn.user = user;
    if (!this.byUser.has(user.id)) { this.byUser.set(user.id, new Set()); this.presenceDirty = true; }
    this.byUser.get(user.id).add(conn);
    this.users.set(user.id, user);
    let chat = [];
    try { chat = await call('chat_recent', { n: CFG.CHAT_HISTORY }); } catch (e) { console.error('chat_recent', e.message); }
    this.send(conn, { t: 'welcome', me: publicMe(user), chat, stakes: CFG.STAKES, modes: Object.values(E.MODES).map((x) => ({ key: x.key, label: x.label, n: x.n, target: x.target })), presence: this.presence(), queue: this.queueOf(user.id) });
    this.resume(conn, user);
  }
  resume(conn, user) {
    const ur = this.userRoom.get(user.id);
    if (ur) {
      const R = this.rooms.get(ur.id);
      if (R) { R.room.setConnected(ur.seat, true); this.send(conn, { t: 'matched', resume: true, view: R.room.view(ur.seat) }); return; }
      this.userRoom.delete(user.id);
    }
    const S = this.salaOf(user.id);
    if (S) { this.salaPush(S); }
  }

  // ---- chat ----
  async chat(conn, user, m) {
    if (user.muted_until > now()) return this.send(conn, { t: 'error', msg: 'No puedes escribir en el chat por ahora.' });
    const text = clean(m.text, CFG.CHAT_MAX);
    if (!text) return;
    if (m.scope === 'mesa') {
      const ur = this.userRoom.get(user.id); if (!ur) return;
      if (!this.tableOk(user.id)) return this.send(conn, { t: 'error', msg: 'Más despacio con los mensajes.' });
      const R = this.rooms.get(ur.id); if (!R) return;
      const msg = { t: 'tchat', seat: ur.seat, name: user.name, text, ts: now() };
      for (const uid of R.seats) if (uid) this.sendUser(uid, msg);
      return;
    }
    if (m.scope === 'sala') {
      const S = this.salaOf(user.id); if (!S) return;
      if (!this.tableOk(user.id)) return this.send(conn, { t: 'error', msg: 'Más despacio con los mensajes.' });
      const msg = { t: 'schat', uid: user.id, name: user.name, avatar: user.avatar, text, ts: now() };
      for (const uid of S.seats) if (uid) this.sendUser(uid, msg);
      S.touched = now();
      return;
    }
    if (!this.chatOk(user.id)) return this.send(conn, { t: 'error', msg: 'Estás escribiendo muy rápido. Espera unos segundos.' });
    const ts = now(), id = await call('chat_add', { uid: user.id, name: user.name, avatar: user.avatar, text, now: ts });
    this.broadcast({ t: 'chat', m: { id, uid: user.id, name: user.name, avatar: user.avatar, text, ts } });
  }
  async report(conn, user, m) {
    if (!this.reportOk(user.id)) return this.send(conn, { t: 'error', msg: 'Ya enviaste varios reportes. Gracias, los revisaremos.' });
    const msg = await call('chat_get', { id: m.id | 0 });
    if (!msg) return;
    await call('report_add', { reporter: user.id, target: msg.user_id, msg_id: msg.id, text: msg.text, reason: clean(m.reason || '', 200), now: now() });
    this.send(conn, { t: 'notice', kind: 'report', msg: 'Gracias. Nuestro equipo revisará ese mensaje.' });
  }
  async deleteChat(id) { await call('chat_delete', { id }); this.broadcast({ t: 'chatdel', id }); }

  // ---- buscar mesa (emparejamiento con cualquier persona conectada, esté donde esté) ----
  queueOf(uid) { for (const [k, list] of this.queues) if (list.some((x) => x.uid === uid)) { const [mode, stake, target] = k.split('|'); return { mode, stake: +stake, target: +target }; } return null; }
  // ¿puede jugar con este monto? (dinero real: cuenta registrada y saldo suficiente)
  moneyBlock(user, stake) {
    if (!user.registered && (stake ? CFG.MONEY_NEEDS_ACCOUNT : CFG.PLAY_NEEDS_ACCOUNT)) return { t: 'error', msg: 'Para jugar, regístrate con tu correo (18+). Es gratis y toma un minuto.', code: 'account' };
    if (!stake) return null;
    if (user.coins < stake) return { t: 'error', msg: 'No te alcanza el saldo para esa mesa.', code: 'coins' };
    return null;
  }
  busy(uid) { return this.userRoom.has(uid) || this.starting.has(uid); }
  queue(conn, user, m) {
    const mode = E.MODES[m.mode] ? m.mode : null, stake = STAKE_OK(m.stake) ? +m.stake : null, target = TGT(m.target);
    if (!mode || stake == null) return this.send(conn, { t: 'error', msg: 'Elige un modo y un monto.' });
    if (this.busy(user.id)) return this.resume(conn, user);
    const why = this.moneyBlock(user, stake); if (why) return this.send(conn, why);
    const S = this.salaOf(user.id); if (S) this.salaRemove(S, user.id, 'salio');
    this.unqueue(user.id);
    const key = mode + '|' + stake + '|' + target;
    if (!this.queues.has(key)) this.queues.set(key, []);
    this.queues.get(key).push({ uid: user.id, since: now() });
    this.sendUser(user.id, { t: 'queued', mode, stake, target, wait: stake && !CFG.MONEY_BOTS ? 0 : CFG.QUEUE_WAIT_MS });
    this.presenceDirty = true;
    this.tick();
  }
  unqueue(uid) {
    for (const [k, list] of this.queues) { const i = list.findIndex((x) => x.uid === uid); if (i >= 0) { list.splice(i, 1); this.presenceDirty = true; if (!list.length) this.queues.delete(k); } }
  }
  tick() {
    for (const [key, list] of this.queues) {
      const [mode, stakeS, targetS] = key.split('|'), stake = +stakeS, n = E.MODES[mode].n, target = +targetS;
      for (let i = list.length - 1; i >= 0; i--) if (!this.online(list[i].uid)) list.splice(i, 1);
      while (list.length >= n) this.createRoom(mode, stake, list.splice(0, n).map((x) => x.uid), { target });
      // con dinero no se completa con la computadora (salvo MONEY_BOTS=1): se espera a personas
      if (list.length && now() - list[0].since >= CFG.QUEUE_WAIT_MS && (stake === 0 || CFG.MONEY_BOTS)) this.createRoom(mode, stake, list.splice(0, list.length).map((x) => x.uid), { target });
      if (!list.length) this.queues.delete(key);
    }
    // salas abandonadas
    for (const S of this.salas.values()) if (S.state === 'espera' && now() - S.touched > CFG.SALA_IDLE_MS) this.salaClose(S, 'La sala se cerró por inactividad.');
    if (this.presenceDirty) { this.presenceDirty = false; this.broadcast({ t: 'presence', ...this.presence() }); }
  }
  presence() {
    const queues = {}; for (const [k, l] of this.queues) queues[k] = l.length;
    let playing = 0; for (const R of this.rooms.values()) playing += R.seats.filter(Boolean).length;
    return { online: this.byUser.size, playing, queues };
  }

  // ---- salas privadas: invitación por enlace o código ----
  salaOf(uid) { const c = this.userSala.get(uid); return c ? this.salas.get(c) || null : null; }
  newCode() { for (;;) { let s = ''; for (let i = 0; i < CFG.SALA_CODE_LEN; i++) s += CODE_ABC[randomInt(CODE_ABC.length)]; if (!this.salas.has(s)) return s; } }
  salaView(S) {
    return {
      code: S.code, mode: S.mode, stake: S.stake, target: S.target, host: S.host, state: S.state, n: S.seats.length,
      seats: S.seats.map((uid) => { if (!uid) return null; const u = this.user(uid) || S.names.get(uid) || {}; return { uid, name: u.name || '…', avatar: u.avatar || null, online: this.online(uid) }; })
    };
  }
  salaInfo(code) {
    const S = this.salas.get(normCode(code)); if (!S) return null;
    const host = this.user(S.host) || S.names.get(S.host) || {};
    return { code: S.code, mode: S.mode, stake: S.stake, target: S.target, n: S.seats.length, players: S.seats.filter(Boolean).length, state: S.state, host: host.name || '' };
  }
  salaPush(S) { const v = this.salaView(S); for (const uid of S.seats) if (uid) this.sendUser(uid, { t: 'sala', sala: v }); }
  salaPut(S, uid, user) { const i = S.seats.indexOf(null); if (i < 0) return false; S.seats[i] = uid; S.names.set(uid, { name: user.name, avatar: user.avatar }); this.userSala.set(uid, S.code); S.touched = now(); return true; }
  salaRemove(S, uid, why) {
    const i = S.seats.indexOf(uid); if (i < 0) return;
    S.seats[i] = null; this.userSala.delete(uid); S.touched = now();
    if (!S.seats.some(Boolean)) { this.salas.delete(S.code); return; }
    if (S.host === uid) { S.host = S.seats.find(Boolean); this.sendUser(S.host, { t: 'notice', kind: 'sala', msg: 'Ahora eres el anfitrión de la sala.' }); }
    if (why === 'expulsado') this.sendUser(uid, { t: 'sala', sala: null, msg: 'El anfitrión te sacó de la sala.' });
    if (why === 'desconectado') this.sendUser(uid, { t: 'sala', sala: null });
    this.salaPush(S);
  }
  salaClose(S, msg) { for (const uid of S.seats) if (uid) { this.userSala.delete(uid); this.sendUser(uid, { t: 'sala', sala: null, msg }); } this.salas.delete(S.code); }
  salaCheck(conn, user, mode, stake) {
    if (this.busy(user.id)) { this.resume(conn, user); return false; }
    const why = this.moneyBlock(user, stake); if (why) { this.send(conn, why); return false; }
    return true;
  }
  async salaCreate(conn, user, m) {
    const mode = E.MODES[m.mode] ? m.mode : 'parejas', stake = STAKE_OK(m.stake) ? +m.stake : CFG.STAKES[0];
    const fresh = (await this.refreshUser(user.id)) || user;
    if (!this.salaCheck(conn, fresh, mode, stake)) return;
    if (!this.salaNewOk(user.id)) return this.send(conn, { t: 'error', msg: 'Creaste muchas salas seguidas. Espera unos minutos.' });
    const old = this.salaOf(user.id); if (old) this.salaRemove(old, user.id, 'salio');
    this.unqueue(user.id);
    const S = { code: this.newCode(), mode, stake, target: TGT(m.target), host: user.id, state: 'espera', seats: Array(E.MODES[mode].n).fill(null), names: new Map(), kicked: new Set(), created: now(), touched: now() };
    this.salas.set(S.code, S);
    this.salaPut(S, user.id, fresh);
    this.salaPush(S);
  }
  async salaJoin(conn, user, m) {
    if (!this.salaJoinOk(user.id)) return this.send(conn, { t: 'error', msg: 'Demasiados intentos. Espera un momento.' });
    const S = this.salas.get(normCode(m.code));
    if (!S) return this.send(conn, { t: 'error', msg: 'Esa sala no existe o ya cerró. Revisa el código.', code: 'sala' });
    if (S.seats.includes(user.id)) { if (S.state === 'jugando') return this.resume(conn, user); return this.salaPush(S); }
    if (S.kicked.has(user.id)) return this.send(conn, { t: 'error', msg: 'No puedes entrar a esa sala.', code: 'sala' });
    if (S.state === 'jugando') return this.send(conn, { t: 'error', msg: 'Esa sala ya está jugando. Espera a que termine la partida.', code: 'sala' });
    if (!S.seats.includes(null)) return this.send(conn, { t: 'error', msg: 'La sala está llena.', code: 'sala' });
    const fresh = (await this.refreshUser(user.id)) || user;
    if (!this.salaCheck(conn, fresh, S.mode, S.stake)) return;
    const old = this.salaOf(user.id); if (old && old !== S) this.salaRemove(old, user.id, 'salio');
    this.unqueue(user.id);
    if (!this.salas.has(S.code) || !this.salaPut(S, user.id, fresh)) return this.send(conn, { t: 'error', msg: 'La sala está llena.', code: 'sala' });
    for (const uid of S.seats) if (uid && uid !== user.id) this.sendUser(uid, { t: 'notice', kind: 'sala', msg: fresh.name + ' entró a la sala.' });
    this.salaPush(S);
  }
  salaSeat(conn, user, m) {
    const S = this.salaOf(user.id); if (!S || S.state !== 'espera') return;
    const to = m.seat | 0; if (to < 0 || to >= S.seats.length || S.seats[to]) return;
    S.seats[S.seats.indexOf(user.id)] = null; S.seats[to] = user.id; S.touched = now();
    this.salaPush(S);
  }
  salaConfig(conn, user, m) {
    const S = this.salaOf(user.id); if (!S || S.state !== 'espera') return;
    if (S.host !== user.id) return this.send(conn, { t: 'error', msg: 'Solo el anfitrión puede cambiar la mesa.' });
    const mode = E.MODES[m.mode] ? m.mode : S.mode, stake = STAKE_OK(m.stake) ? +m.stake : S.stake, n = E.MODES[mode].n;
    const members = S.seats.filter(Boolean);
    if (members.length > n) return this.send(conn, { t: 'error', msg: `Hay demasiadas personas en la sala para ${E.MODES[mode].label} (máximo ${n}).` });
    if (m.target != null) S.target = TGT(m.target);
    if (mode !== S.mode) { S.seats = Array(n).fill(null); members.forEach((uid, i) => { S.seats[i] = uid; }); }
    S.mode = mode; S.stake = stake; S.touched = now();
    this.salaPush(S);
  }
  salaKick(conn, user, m) {
    const S = this.salaOf(user.id); if (!S || S.host !== user.id || S.state !== 'espera') return;
    const uid = +m.uid; if (!uid || uid === user.id || !S.seats.includes(uid)) return;
    S.kicked.add(uid); this.salaRemove(S, uid, 'expulsado');
  }
  async salaStart(conn, user) {
    const S = this.salaOf(user.id); if (!S || S.state !== 'espera') return;
    if (S.host !== user.id) return this.send(conn, { t: 'error', msg: 'Solo el anfitrión puede empezar la partida.' });
    const humans = S.seats.filter(Boolean);
    if (humans.length < 2 && !CFG.SALA_SOLO) return this.send(conn, { t: 'error', msg: 'Invita al menos a una persona para empezar.' });
    if (S.stake && !CFG.MONEY_BOTS && humans.length < S.seats.length) return this.send(conn, { t: 'error', msg: 'Las mesas con dinero se juegan solo entre personas: faltan ' + (S.seats.length - humans.length) + '.' });
    for (const uid of humans) if (this.busy(uid)) return this.send(conn, { t: 'error', msg: 'Alguien de la sala todavía está en otra mesa.' });
    S.state = 'jugando'; S.touched = now();
    this.salaPush(S);
    const ok = await this.createRoom(S.mode, S.stake, humans, { seats: S.seats.slice(), sala: S, target: S.target });
    if (!ok && this.salas.has(S.code)) { S.state = 'espera'; this.salaPush(S); }
  }

  // ---- mesas ----
  // uids: quiénes juegan. opts.seats: asientos fijos (salas). Devuelve true si la mesa empezó.
  async createRoom(mode, stake, uids, opts = {}) {
    const n = E.MODES[mode].n, id = randomBytes(6).toString('hex'), S = opts.sala || null;
    uids.forEach((u) => this.starting.add(u));
    let res;
    try {
      res = stake === 0 ? { charged: uids.map((uid) => ({ uid, coins: this.user(uid)?.coins ?? null })), failed: [] } // partida gratis: no se cobra
        : await call('match_start', { id, mode, stake, uids, room_code: S ? S.code : null, fee_rate: CFG.PLATFORM_FEE, now: now() });
    }
    catch (e) {
      console.error('match_start', e.message);
      for (const uid of uids) this.sendUser(uid, { t: 'error', msg: 'No se pudo crear la mesa. Intenta otra vez.' });
      return false;
    } finally { uids.forEach((u) => this.starting.delete(u)); }
    for (const uid of res.failed) {
      this.sendUser(uid, { t: 'error', msg: 'No te alcanza el saldo para esa mesa.', code: 'coins' });
      if (S) this.salaRemove(S, uid, 'salio');
    }
    const paid = new Map(res.charged.map((c) => [c.uid, c.coins]));
    if (!paid.size) return false;
    let seats;
    if (opts.seats) seats = opts.seats.map((uid) => (uid && paid.has(uid) ? uid : null));
    else { seats = Array(n).fill(null); const free = [...Array(n).keys()]; for (const uid of paid.keys()) { const k = Math.floor(Math.random() * free.length); seats[free.splice(k, 1)[0]] = uid; } }
    const names = BOT_NAMES.slice().sort(() => Math.random() - 0.5);
    const players = seats.map((uid, i) => {
      if (uid) { const u = this.user(uid) || (S && S.names.get(uid)) || { name: 'Jugador', avatar: P.random() }; return { uid, name: u.name, avatar: u.avatar, bot: false }; }
      return { name: names[i], avatar: P.random(), bot: true };
    });
    call('match_players', { id, players: players.map((p) => ({ uid: p.uid || null, name: p.name, bot: p.bot })) }).catch((e) => console.error('match_players', e.message));
    const R = { mode, stake, seats, created: now(), sala: S ? S.code : null };
    R.room = new Room({
      id, mode, stake, players, target: opts.target, prize: prizeFor(stake, mode),
      send: (seat, msg) => { const uid = seats[seat]; if (uid && this.userRoom.get(uid)?.id === id) this.sendUser(uid, msg); },
      onEnd: (info) => { this.settle(id, info).catch((e) => console.error('settle', e)); },
      onLog: (k, e) => console.error('room', k, e),
      timing: CFG.TIME_SCALE !== 1 ? Object.fromEntries(Object.entries(Room.TIMING).map(([k, v]) => [k, Array.isArray(v) ? v.map((x) => x * CFG.TIME_SCALE) : v * CFG.TIME_SCALE])) : undefined
    });
    this.rooms.set(id, R);
    seats.forEach((uid, seat) => { if (uid) { this.userRoom.set(uid, { id, seat }); this.unqueue(uid); } });
    for (const [uid, coins] of paid) {
      const u = this.user(uid); if (u && coins != null) u.coins = coins;
      if (stake) this.sendUser(uid, { t: 'coins', coins, delta: -stake, reason: 'apuesta' });
      if (!this.online(uid)) R.room.setConnected(seats.indexOf(uid), false);
    }
    R.room.start();
    seats.forEach((uid, seat) => { if (uid) this.sendUser(uid, { t: 'matched', view: R.room.view(seat), sala: R.sala }); });
    this.presenceDirty = true;
    return true;
  }

  act(conn, user, m) {
    const ur = this.userRoom.get(user.id); if (!ur) return this.send(conn, { t: 'error', msg: 'No estás en una mesa.' });
    const R = this.rooms.get(ur.id); if (!R) return;
    const err = R.room.action(ur.seat, m.a);
    if (err) this.send(conn, { t: 'reject', msg: err, a: m.a });
  }
  leave(conn, user) {
    const ur = this.userRoom.get(user.id);
    if (!ur) { this.send(conn, { t: 'left' }); return; }
    const R = this.rooms.get(ur.id);
    if (R && !R.room.ended) R.room.leave(ur.seat);
    this.userRoom.delete(user.id);
    // quien abandona una partida de sala, sale también de la sala
    if (R && R.sala) { const S = this.salas.get(R.sala); if (S && S.seats.includes(user.id)) this.salaRemove(S, user.id, 'salio'); }
    this.sendUser(user.id, { t: 'left' });
    this.presenceDirty = true;
  }

  // ---- fin de la partida: premios ----
  async settle(id, info) {
    const R = this.rooms.get(id); if (!R) return;
    const prize = prizeFor(R.stake, R.mode); // el pozo (doble o triple) menos la comisión de la plataforma
    const results = [];
    for (const p of info.players) {
      const uid = R.seats[p.seat]; if (!uid) continue;
      const stillHere = this.userRoom.get(uid)?.id === id;
      results.push({ uid, seat: p.seat, won: p.team === info.winnerTeam && stillHere });
    }
    const result = { scores: info.scores, winnerTeam: info.winnerTeam, results: results.map(({ uid, seat, won }) => ({ uid, seat, won })) };
    let out = R.stake === 0 ? [] : null; // gratis: no hay premio
    for (let i = 0; i < 4 && !out; i++) {
      try { out = await call('match_settle', { id, stake: R.stake, prize, results: results.map((r) => ({ uid: r.uid, won: r.won })), result, now: now() }); }
      catch (e) { console.error('match_settle', e.message); await new Promise((r) => setTimeout(r, 1500 * (i + 1))); }
    }
    const coins = new Map((out || []).map((x) => [x.uid, x.coins]));
    for (const r of results) {
      if (this.userRoom.get(r.uid)?.id !== id) continue;
      const u = await this.refreshUser(r.uid).catch(() => null);
      const c = coins.get(r.uid) ?? u?.coins;
      if (c != null && R.stake) this.sendUser(r.uid, { t: 'coins', coins: c, delta: r.won ? prize : 0, reason: r.won ? 'premio' : 'partida perdida' });
      if (u) this.sendUser(r.uid, { t: 'me', me: publicMe(u) });
      this.userRoom.delete(r.uid);
    }
    // la sala vuelve a la espera para la revancha
    if (R.sala) { const S = this.salas.get(R.sala); if (S) { S.state = 'espera'; S.touched = now(); for (const uid of S.seats) if (uid && !this.online(uid)) S.seats[S.seats.indexOf(uid)] = null, this.userSala.delete(uid); if (S.seats.some(Boolean)) { if (!S.seats.includes(S.host)) S.host = S.seats.find(Boolean); this.salaPush(S); } else this.salas.delete(S.code); } }
    setTimeout(() => { R.room.destroy(); this.rooms.delete(id); this.presenceDirty = true; }, 5000);
  }

  notify(uid, msg) { this.sendUser(uid, msg); }
  kick(uid, reason) { const set = this.byUser.get(uid); if (set) for (const c of set) { c.ws.send(JSON.stringify({ t: 'banned', reason })); c.ws.close(4003); } }
  stats() { return { ...this.presence(), rooms: this.rooms.size, salas: this.salas.size, sockets: this.socks.size }; }
  stop() { this.timers.forEach(clearInterval); for (const R of this.rooms.values()) R.room.destroy(); }
}
