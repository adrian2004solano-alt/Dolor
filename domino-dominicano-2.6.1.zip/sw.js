// Dominó Dominicano · service worker (modo sin conexión)
// Guarda el juego en el teléfono para que abra rápido y se pueda jugar sin internet.
// IMPORTANTE: sube VERSION en cada publicación (igual que APP_VERSION en js/app/version.js) para que los jugadores
// reciban la versión nueva.
const VERSION = '2.6.1';
const CACHE = 'domino-' + VERSION;
const CORE = [
  './', 'index.html', 'reglas.html', 'privacidad.html', 'terminos.html', 'manifest.webmanifest', 'css/game.css', 'css/lobby.css', 'css/pages.css',
  'shared/engine.js', 'shared/room.js', 'shared/profile.js',
  'js/app/loader.js', 'js/app/version.js', 'js/app/server-url.js', 'js/app/main.js', 'js/lobby/net.js', 'js/lobby/lobby.js', 'js/lobby/sala.js', 'js/lobby/home.js',
  'js/core/config.js', 'js/core/screen.js', 'js/core/projection.js', 'js/core/audio.js',
  'js/render/theme.js', 'js/render/tile.js', 'js/game/state.js', 'js/render/racks.js', 'js/game/layout.js',
  'js/game/flow.js', 'js/game/driver.js', 'js/game/input.js', 'js/game/update.js', 'js/render/hud.js',
  'js/render/textures.js', 'js/render/ambient.js', 'js/render/table.js', 'js/render/scene.js',
  'assets/icons/favicon.svg', 'assets/icons/icon-192.png', 'assets/icons/icon-512.png'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(CORE)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k.startsWith('domino-') && k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// Páginas: primero internet (para tener siempre lo último), si no hay, lo guardado.
// Archivos del juego: primero lo guardado (rápido) y se actualiza en segundo plano.
self.addEventListener('fetch', (e) => {
  const req = e.request;
  const u = new URL(req.url);
  if (req.method !== 'GET' || u.origin !== location.origin || /\/api\/|\/ws$|admin/.test(u.pathname)) return;
  if (req.mode === 'navigate') {
    e.respondWith(
      fetch(req).then((res) => { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); return res; })
        .catch(() => caches.match(req, { ignoreSearch: true }).then((r) => r || caches.match('./')))
    );
    return;
  }
  e.respondWith(
    caches.match(req, { ignoreSearch: true }).then((cached) => {
      const net = fetch(req).then((res) => {
        if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(req, copy)); }
        return res;
      }).catch(() => cached);
      return cached || net;
    })
  );
});
