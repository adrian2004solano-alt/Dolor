# App para Android (APK)

El juego ya es una **app web instalable** (PWA): en Android, Chrome ofrece "Instalar app" y el botón **Descargar la app**
del inicio abre esa instalación. Para tener además un archivo **.apk** (o .aab para Google Play):

1. Publica el juego con tu dominio (https).
2. Entra a **pwabuilder.com**, escribe la dirección de tu juego y elige **Android** → genera el paquete
   (es una "Trusted Web Activity": la app abre tu sitio a pantalla completa, sin barra del navegador).
3. Del paquete descargado:
   - sube `assetlinks.json` a esta carpeta del proyecto: `.well-known/assetlinks.json` (el servidor ya lo publica en
     `https://tu-dominio/.well-known/assetlinks.json`), para que la app se abra sin barra de dirección;
   - copia el `.apk` a `descargas/domino.apk`.
4. En el servidor pon la variable `APK_URL=/descargas/domino.apk` y vuelve a publicar.

Para Google Play usa el `.aab`. Ten en cuenta que Google Play tiene reglas propias para apps con dinero real.
