# Publicar en Google Cloud Run

Este proyecto es **un servidor de Node.js** (juego en línea, salas, billetera, admin) más la página. Google AI Studio
está hecho para sus propias apps y no corre este servidor tal cual. En Google, lo correcto es **Cloud Run**, que usa el
`Dockerfile` incluido.

1. Instala Google Cloud CLI (`gcloud`) y entra: `gcloud auth login` y `gcloud config set project TU-PROYECTO`.
2. Desde la carpeta del proyecto (donde está `index.html` y `Dockerfile`):

```bash
gcloud run deploy domino --source . --region us-east1 --allow-unauthenticated \
  --min-instances 1 --max-instances 1 --no-cpu-throttling --timeout 3600 \
  --set-env-vars "SUPABASE_URL=https://TU-PROYECTO.supabase.co,ADMIN_KEY=tu-clave-larga,MAIL_FROM=Dominó <no-responder@tu-dominio.com>" \
  --set-secrets "SUPABASE_SECRET_KEY=supabase-secret:latest,RESEND_API_KEY=resend-key:latest"
```

- `--max-instances 1`: las mesas y salas en vivo están en la memoria del servidor (una sola instancia).
- `--min-instances 1` y `--no-cpu-throttling`: el servidor sigue despierto y los relojes de las partidas funcionan.
- `--timeout 3600`: las conexiones en tiempo real duran hasta 1 hora; el juego se reconecta solo.
- Las claves secretas guárdalas en **Secret Manager** (`supabase-secret`, `resend-key`) y no en el comando.

3. Abre la dirección que te da Cloud Run y revisa `https://…/api/health` → `"dbOk": true`.

## ¿Y si solo subo los archivos a un hosting de páginas (sin servidor)?

La página abre igual, en **modo sin conexión**: se ve el inicio, la tienda y se puede jugar la práctica contra la
computadora, pero sin cuentas, dinero, salas ni partidas en línea. Para eso hace falta el servidor (Cloud Run, Railway,
Render…). Si la página va en un hosting y el servidor en otro, pon la dirección del servidor en `js/app/server-url.js`
y en el servidor `ALLOWED_ORIGINS=https://donde-esta-la-pagina`.
