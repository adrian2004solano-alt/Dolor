/* Dominó Dominicano · mesa (compartida)
 * Lleva una partida completa sobre el motor de reglas: turnos con tiempo, jugadores de la computadora, quien se
 * desconecta (la computadora juega por él mientras vuelve) y el ritmo de los eventos para que las animaciones del
 * juego tengan tiempo de verse. La usa el servidor para las mesas en línea y el navegador para el modo práctica.
 *
 * new Room({ mode, players:[{name, avatar, bot, uid}], send(seat, msg), onEnd(info), seed, timing })
 *   room.start()                 empieza la partida
 *   room.action(seat, accion)    { t:'pick', i } · { t:'play', tile, end } · { t:'pass' }
 *   room.setConnected(seat, b)   el jugador se conectó / desconectó
 *   room.leave(seat)             el jugador abandonó (en parejas y 1 vs 1 lo reemplaza la computadora;
 *                                en tríos sale de la mesa y siguen los demás)
 *   room.view(seat)              todo lo que ese jugador necesita para redibujar la mesa (al reconectarse)
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./engine.js'));
  else root.DomRoom = factory(root.DomEngine);
})(typeof self !== 'undefined' ? self : this, function (E) {
  'use strict';

  // tiempos (ms) que dejan ver cada animación del juego antes de que la mesa siga sola
  const T = {
    shuffle: 3700,          // barajado + fichas acomodándose antes de poder tomarlas
    botPick: [450, 1100],   // la computadora toma una ficha cada…
    pickLimit: 20000,       // si no tomas tus fichas en este tiempo, se toman solas
    afterStart: 900, afterPlay: 900, afterPass: 1450, afterCorrido: 3100, afterDraw: 650, afterTurn: 0,
    botThink: [900, 1700],  // lo que "piensa" la computadora
    turn: 25000,            // tiempo de tu turno
    autoPass: 6000,         // si no llevas, pasas solo después de…
    offline: 2500,          // si estás desconectado, la computadora juega por ti después de…
    roundEnd: 2900, roundEndCap: 5600, // golpe final (y capicúa) antes de barajar otra vez
    dropAfter: 45000,       // tríos: si alguien sigue desconectado después de esto, sale de la mesa
    nextMatch: 0
  };
  const rand = (r, a, b) => a + r() * (b - a);

  class Room {
    constructor(o) {
      this.id = o.id || 'practica';
      this.mode = o.mode || 'parejas';
      this.stake = o.stake || 0;
      this.prize = o.prize != null ? o.prize : this.stake * E.numTeams(this.mode);
      this.players = o.players.map((p) => Object.assign({ connected: !p.bot, left: false }, p));
      this.sendFn = o.send || function () {};
      this.onEnd = o.onEnd || function () {};
      this.onLog = o.onLog || null;
      this.T = Object.assign({}, T, o.timing || {});
      this.target = E.TARGETS.includes(+o.target) ? +o.target : E.MODES[this.mode].target;
      this.st = E.newMatch(this.mode, { seed: o.seed, target: this.target });
      this.dropTimers = {};
      this.r = E.rngFrom((o.seed || Math.floor(Math.random() * 4294967296)) ^ 0x5bd1e995);
      this.timer = null; this.pickTimers = []; this.ended = false; this.busyUntil = 0;
      this.deadline = 0; this.chat = [];
    }
    now() { return Date.now(); }
    auto(seat) { const p = this.players[seat]; return p.bot || p.left || !p.connected; }
    info() { return this.players.map((p, i) => ({ seat: i, name: p.name, avatar: p.avatar || null, bot: !!p.bot, left: !!p.left, out: !!this.st.out[i], connected: !!p.connected, uid: p.uid || null })); }

    send(seat, msg) { try { this.sendFn(seat, msg); } catch (e) { if (this.onLog) this.onLog('send', e); } }
    emit(events) {
      if (!events.length) return;
      for (let s = 0; s < this.players.length; s++) {
        const e = E.redact(events, s);
        // a quien le toca: sus jugadas posibles y cuánto tiempo tiene
        for (const x of e) if (x.type === 'turn') {
          const can = E.canPlay(this.st, x.p);
          x.ms = this.auto(x.p) ? 1300 : (can ? this.T.turn : this.T.autoPass);
          if (x.p === s) x.legal = E.legal(this.st, s);
        }
        this.send(s, { t: 'ev', e });
      }
      // cuánto dura lo que acaba de pasar en pantalla
      let wait = 0;
      for (const x of events) {
        wait += x.type === 'play' ? this.T.afterPlay : x.type === 'pass' ? this.T.afterPass : x.type === 'corrido' ? this.T.afterCorrido
          : x.type === 'draw' ? this.T.afterDraw : x.type === 'start' ? this.T.afterStart : 0;
        if (x.type === 'roundEnd') wait += x.cap ? this.T.roundEndCap : this.T.roundEnd;
      }
      this.busyUntil = Math.max(this.busyUntil, this.now()) + wait;
    }

    start() { this.newRound(); }
    newRound() {
      this.clear();
      const ev = E.startRound(this.st);
      this.busyUntil = this.now();
      this.emit(ev);
      this.pickOpen = this.now() + this.T.shuffle;
      this.deadline = this.pickOpen + this.T.pickLimit;
      this.schedulePicks();
    }
    clear() { clearTimeout(this.timer); this.timer = null; this.pickTimers.forEach(clearTimeout); this.pickTimers = []; }

    schedulePicks() {
      const st = this.st;
      st.hands.forEach((h, seat) => {
        const step = () => {
          if (st.phase !== 'pick' || this.ended || st.out[seat]) return;
          if (st.hands[seat].length >= st.cfg.deal) return;
          if (this.auto(seat) || this.now() >= this.deadline) {
            const i = E.botPick(st, this.r);
            if (i >= 0) this.apply(() => E.pick(st, seat, i));
          }
          this.pickTimers.push(setTimeout(step, this.auto(seat) || this.now() >= this.deadline ? rand(this.r, this.T.botPick[0], this.T.botPick[1]) : 400));
        };
        this.pickTimers.push(setTimeout(step, Math.max(0, this.pickOpen - this.now()) + rand(this.r, 250, 1100)));
      });
    }

    apply(fn) {
      let ev;
      try { ev = fn(); } catch (e) { return e.message || String(e); }
      this.emit(ev);
      this.schedule();
      return null;
    }

    // qué hace la mesa sola a continuación (computadora, tiempo agotado, siguiente mano…)
    schedule() {
      clearTimeout(this.timer); this.timer = null;
      const st = this.st, t0 = Math.max(this.busyUntil, this.now()), wait = (ms) => Math.max(0, t0 + ms - this.now());
      if (this.ended) return;
      if (st.phase === 'pick') return;
      if (st.phase === 'play') {
        this.pickTimers.forEach(clearTimeout); this.pickTimers = [];
        const p = st.turn, me = this.players[p];
        const can = E.canPlay(st, p);
        if (me.bot || me.left) {
          this.deadline = 0;
          this.timer = setTimeout(() => this.autoAct(p), wait(rand(this.r, this.T.botThink[0], this.T.botThink[1])));
        } else if (!me.connected) {
          this.deadline = t0 + this.T.offline;
          this.timer = setTimeout(() => this.autoAct(p), wait(this.T.offline));
        } else {
          const ms = can ? this.T.turn : this.T.autoPass;
          this.deadline = t0 + ms;
          this.timer = setTimeout(() => this.autoAct(p), wait(ms));
        }
        return;
      }
      if (st.phase === 'roundEnd') { this.timer = setTimeout(() => this.newRound(), wait(0)); return; }
      if (st.phase === 'over' && !this.ended) {
        this.ended = true;
        this.timer = setTimeout(() => this.finish(), wait(0));
      }
    }
    autoAct(p) {
      const st = this.st;
      if (st.phase !== 'play' || st.turn !== p) return;
      const m = E.botMove(st, p, this.r);
      if (m) this.apply(() => E.play(st, p, m.id, m.end));
      else this.apply(() => E.pass(st, p));
    }
    finish() {
      const st = this.st;
      const info = { id: this.id, mode: this.mode, stake: this.stake, target: this.target, prize: this.prize, scores: st.scores.slice(), winnerTeam: st.winnerTeam, rounds: st.round, players: this.info().map((p) => Object.assign(p, { team: E.teamOf(st, p.seat) })) };
      for (let s = 0; s < this.players.length; s++) this.send(s, { t: 'end', info });
      this.onEnd(info);
    }

    // ---- acciones de los jugadores ----
    action(seat, a) {
      const st = this.st, me = this.players[seat];
      if (!me || me.left) return 'No estás en esta mesa';
      if (!a || typeof a !== 'object') return 'Acción inválida';
      if (a.t === 'pick') {
        if (this.now() < this.pickOpen - 300) return 'Espera a que terminen de barajar';
        return this.apply(() => E.pick(st, seat, a.i | 0));
      }
      if (a.t === 'play') return this.apply(() => E.play(st, seat, a.tile | 0, a.end));
      if (a.t === 'pass') return this.apply(() => E.pass(st, seat));
      return 'Acción desconocida';
    }
    setConnected(seat, on) {
      const p = this.players[seat]; if (!p || p.bot) return;
      p.connected = on;
      // tríos: quien no vuelve a tiempo sale de la mesa
      clearTimeout(this.dropTimers[seat]);
      if (!on && this.st.cfg.dropOnLeave && !this.ended) this.dropTimers[seat] = setTimeout(() => { if (!p.connected) this.leave(seat); }, this.T.dropAfter);
      this.broadcast({ t: 'seat', seat, connected: on, left: p.left });
      if (this.st.phase === 'play' && this.st.turn === seat) this.schedule();
    }
    leave(seat) {
      const p = this.players[seat]; if (!p || p.bot || p.left) return;
      p.left = true; p.connected = false;
      this.broadcast({ t: 'seat', seat, connected: false, left: true });
      if (this.st.cfg.dropOnLeave) { this.apply(() => E.drop(this.st, seat)); return; }
      if (this.st.phase === 'play' && this.st.turn === seat) this.schedule();
    }
    broadcast(msg) { for (let s = 0; s < this.players.length; s++) this.send(s, msg); }
    view(seat) {
      const v = E.viewFor(this.st, seat);
      v.room = { id: this.id, mode: this.mode, stake: this.stake, target: this.target, prize: this.prize };
      v.seats = this.info();
      v.deadlineIn = this.deadline ? Math.max(0, this.deadline - this.now()) : 0;
      v.pickOpenIn = Math.max(0, (this.pickOpen || 0) - this.now());
      return v;
    }
    destroy() { this.ended = true; this.clear(); Object.values(this.dropTimers).forEach(clearTimeout); }
  }

  Room.TIMING = T;
  return Room;
});
