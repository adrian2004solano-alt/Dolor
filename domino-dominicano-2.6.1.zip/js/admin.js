// Dominó Dominicano · panel de soporte (consultas, reportes, jugadores, chat)
(function(){
 const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
 const h=(t,a,...k)=>{const e=document.createElement(t);for(const x in a||{}){if(x==='class')e.className=a[x];else if(x.startsWith('on'))e.addEventListener(x.slice(2),a[x]);else if(a[x]!=null)e.setAttribute(x,a[x])}for(const c of k.flat())if(c!=null)e.append(c.nodeType?c:document.createTextNode(String(c)));return e};
 const when=t=>t?new Date(t).toLocaleString('es-DO'):'—';
 const money=c=>{c=Math.round(+c||0);const n=c<0;c=Math.abs(c);return(n?'−':'')+'$'+(c/100).toLocaleString('en-US',{minimumFractionDigits:c%100?2:0,maximumFractionDigits:2})};
 let KEY=sessionStorage.getItem('domino.admin')||'';
 const toast=(m,k)=>{const t=h('div',{class:'toast '+(k||'')},m);$('#toasts').append(t);setTimeout(()=>t.remove(),3500)};
 async function api(p,body){const r=await fetch(p,{method:body?'POST':'GET',headers:{'Content-Type':'application/json','X-Admin-Key':KEY},body:body?JSON.stringify(body):undefined});
  const d=await r.json().catch(()=>({}));if(!r.ok){if(r.status===401){sessionStorage.removeItem('domino.admin');location.reload()}throw new Error(d.error||'Error')}return d}
 $('#login').onsubmit=async e=>{e.preventDefault();KEY=$('#key').value;try{await api('/api/admin/stats');sessionStorage.setItem('domino.admin',KEY);start()}catch(err){toast(err.message,'bad')}};
 $('#out').onclick=()=>{sessionStorage.removeItem('domino.admin');location.reload()};
 $$('.atabs button').forEach(b=>b.onclick=()=>{$$('.atabs button').forEach(x=>x.classList.toggle('on',x===b));$$('#app section').forEach(s=>s.hidden=s.id!=='t-'+b.dataset.t);load(b.dataset.t)});
 async function start(){$('#login').hidden=true;$('#app').hidden=false;$('#out').hidden=false;kpis();load('tickets');setInterval(kpis,15000)}
 async function kpis(){const s=await api('/api/admin/stats');const box=$('#kpis');box.innerHTML='';
  for(const[v,l]of[[s.pendingPays,'recargas/retiros por revisar'],[s.users,'jugadores en total'],[s.registered,'registrados con correo'],[s.online,'en línea ahora'],[s.playing,'jugando ahora'],[s.matchesToday,'partidas hoy'],[s.openTickets,'mensajes sin responder'],[s.openReports,'reportes'],[money(s.coins),'saldo de los jugadores']])box.append(h('div',{class:'stat'},h('b',{},v),h('span',{},l)))}
 const fmtN=n=>Number(n||0).toLocaleString('es-DO');
 async function loadRevenue(){const r=await api('/api/admin/revenue');
  $('#revNote').textContent='La plataforma cobra el '+Math.round(r.fee*100)+'% de lo que juega cada persona en cada partida con dinero. Cantidades en dólares. "Neto" = lo cobrado menos los premios pagados (incluye lo que se paga cuando gana alguien contra la computadora).';
  const k=$('#revKpis');k.innerHTML='';
  for(const[lab,x]of[['Hoy',r.today],['7 días',r.week],['30 días',r.month],['Total',r.total]])k.append(h('div',{class:'stat big'},h('span',{},lab),h('b',{},money(x.fee)),h('span',{},'comisión · '+fmtN(x.matches)+' partidas'),h('small',{class:'fine'},'cobrado '+money(x.collected)+' · pagado '+money(x.paid)+' · neto '+money(x.net))));
  const d=$('#revDaily');d.innerHTML='';const max=Math.max(1,...r.daily.map(x=>x.fee));
  if(!r.daily.length)d.append(h('p',{class:'fine'},'Todavía no hay partidas con dinero.'));
  for(const x of r.daily)d.append(h('div',{class:'bar',title:money(x.fee)+' · '+x.matches+' partidas'},h('i',{style:'height:'+Math.max(2,Math.round(100*x.fee/max))+'%'}),h('b',{},money(x.fee)),h('small',{},new Date(x.day+12*3600e3).toLocaleDateString('es-DO',{day:'numeric',month:'short',timeZone:'UTC'}))));
  const o=$('#revOther');o.innerHTML='';for(const[v,l]of[[money(r.shop.amount),'ventas en la tienda ('+r.shop.sales+')'],[money(r.wallet.deposits),'recargas aprobadas'],[money(r.wallet.withdrawals),'retiros enviados'],[r.wallet.pending,'solicitudes pendientes']])o.append(h('div',{class:'stat'},h('b',{},v),h('span',{},l)));
  const t=$('#revModes');t.innerHTML='';t.append(h('tr',{},...['Modo','Partidas','Cobrado','Comisión'].map(x=>h('th',{},x))));
  const MN={parejas:'Parejas',duelo:'1 vs 1',trio:'Tríos'};for(const m of r.byMode)t.append(h('tr',{},h('td',{},MN[m.mode]||m.mode),h('td',{},fmtN(m.matches)),h('td',{},money(m.collected)),h('td',{},money(m.fee))))}
 function load(t){({pays:loadPays,revenue:loadRevenue,tickets:loadTickets,reports:loadReports,users:loadUsers,chat:loadChat})[t]()}
 $('#tkFilter').onchange=loadTickets;
 $('#payFilter').onchange=loadPays;
 async function loadPays(){const st=$('#payFilter').value,r=await api('/api/admin/pays'+(st?'?estado='+st:'')),ul=$('#payList');ul.innerHTML='';
  if(!r.items.length)ul.append(h('li',{class:'fine'},'No hay solicitudes.'));
  for(const x of r.items){const dep=x.kind==='deposit',note=h('input',{placeholder:'Nota para el jugador (opcional)',maxlength:200});
   const act=async ok=>{if(!confirm((ok?(dep?'¿Aprobar y acreditar ':'¿Marcar como enviado el retiro de '):(dep?'¿Rechazar la recarga de ':'¿Rechazar y devolver '))+money(x.amount)+' a '+x.name+'?'))return;
    try{await api('/api/admin/pays/'+x.id,{approve:ok,note:note.value});toast('Listo','good');loadPays();kpis()}catch(e){toast(e.message,'bad')}};
   ul.append(h('li',{class:'card'},h('p',{},h('b',{},(dep?'Recarga ':'Retiro ')+money(x.amount)),' · '+x.method+' · ',h('span',{class:'tag '+x.status},x.status)),
    h('p',{},(dep?'Referencia: ':'Enviar a: ')+(x.details||'—')),
    h('p',{class:'fine'},x.name+' (#'+x.user_id+')'+(x.email?' · '+x.email:'')+' · saldo '+money(x.coins)+' · '+when(x.created)+(x.note?' · nota: '+x.note:'')),
    x.status==='pendiente'?h('div',{class:'row'},note,h('button',{class:'btn gold',onclick:()=>act(true)},dep?'Aprobar':'Marcar enviado'),h('button',{class:'btn ghost',onclick:()=>act(false)},'Rechazar')):null))}}
 async function loadTickets(){const r=await api('/api/admin/tickets'+($('#tkFilter').value?'?estado='+$('#tkFilter').value:''));const ul=$('#tkList');ul.innerHTML='';
  if(!r.items.length)ul.append(h('li',{class:'fine'},'No hay consultas.'));
  for(const t of r.items)ul.append(h('li',{},h('button',{onclick:()=>openTicket(t.id)},h('span',{},(t.unread_admin?'● ':'')+t.subject,h('br'),h('small',{class:'fine'},t.name+' · '+t.category+' · '+when(t.updated))),h('span',{class:'tag '+t.status},t.status))))}
 async function openTicket(id){const r=await api('/api/admin/tickets/'+id),v=$('#tkView');v.innerHTML='';const t=r.ticket;
  v.append(h('h2',{},t.subject),h('p',{class:'fine'},t.name+' (#'+t.uid+') · saldo '+money(t.coins)+' · '+t.category));
  const th=h('div',{class:'thread'});for(const m of r.messages)th.append(h('div',{class:'bubble'+(m.admin?' admin':'')},h('small',{},(m.admin?'Soporte':t.name)+' · '+when(m.created)),m.text));v.append(th);
  const ta=h('textarea',{rows:4,placeholder:'Respuesta…'}),close=h('input',{type:'checkbox',style:'width:auto'});
  v.append(h('form',{class:'form',onsubmit:async e=>{e.preventDefault();try{await api('/api/admin/tickets/'+id+'/reply',{text:ta.value,close:close.checked});toast('Respuesta enviada','good');openTicket(id);loadTickets();kpis()}catch(err){toast(err.message,'bad')}}},
   ta,h('label',{style:'display:flex;gap:8px;align-items:center'},close,'Cerrar la consulta al responder'),h('div',{class:'row'},h('button',{class:'btn gold'},'Responder'),coinsBtn(t.uid,t.name))))}
 function coinsBtn(uid,name){return h('button',{type:'button',class:'btn ghost',onclick:()=>openCoins(uid,name,$('#tkView'))},'Ajustar saldo')}
 function openCoins(uid,name,v){const old=document.getElementById('coinsForm');if(old)old.remove();const inp=h('input',{type:'number',id:'amt',placeholder:'Dólares: 5 para regalar · -2.50 para restar',step:'0.01'}),rs=h('input',{placeholder:'Motivo'});
  v.append(h('form',{id:'coinsForm',class:'form inline',onsubmit:async e=>{e.preventDefault();try{const r=await api('/api/admin/users/'+uid+'/coins',{delta:Math.round(+inp.value*100),reason:rs.value});toast(name+' ahora tiene '+money(r.coins),'good')}catch(err){toast(err.message,'bad')}}},h('label',{},'Saldo para '+name+' (US$)',inp),rs,h('button',{class:'btn gold'},'Aplicar')))}
 async function loadReports(){const r=await api('/api/admin/reports'),ul=$('#repList');ul.innerHTML='';if(!r.items.length)ul.append(h('li',{class:'fine'},'Sin reportes pendientes.'));
  for(const x of r.items)ul.append(h('li',{class:'card'},h('p',{},h('b',{},x.target||'?'),' escribió: "'+x.text+'"'),h('p',{class:'fine'},'Reportado por '+(x.reporter||'?')+' · '+when(x.created)),
   h('div',{class:'row'},h('button',{class:'btn ghost',onclick:async()=>{await api('/api/admin/chat/'+x.msg_id+'/delete',{});await api('/api/admin/reports/'+x.id+'/resolve',{});loadReports();kpis()}},'Borrar mensaje'),
    h('button',{class:'btn ghost',onclick:async()=>{await api('/api/admin/users/'+x.target_id+'/mute',{minutes:60});await api('/api/admin/reports/'+x.id+'/resolve',{});toast('Silenciado 1 hora','good');loadReports();kpis()}},'Silenciar 1 hora'),
    h('button',{class:'btn ghost',onclick:async()=>{await api('/api/admin/reports/'+x.id+'/resolve',{});loadReports();kpis()}},'Descartar'))))}
 $('#uSearch').onsubmit=e=>{e.preventDefault();loadUsers()};
 async function loadUsers(){const r=await api('/api/admin/users?q='+encodeURIComponent($('#uq').value||'')),tb=$('#uTable');tb.innerHTML='';
  tb.append(h('tr',{},...['#','Nombre','Saldo','Partidas','Ganadas','Última vez','Estado',''].map(x=>h('th',{},x))));
  for(const u of r.items){const muted=u.muted_until>Date.now();
   tb.append(h('tr',{},h('td',{},u.id),h('td',{},u.name+(u.registered?'':' (invitado)')),h('td',{},money(u.coins)),h('td',{},u.games),h('td',{},u.wins),h('td',{},when(u.last_seen)),h('td',{},u.banned?'Suspendido':muted?'Silenciado':'Activo'),
    h('td',{},h('div',{class:'row',style:'margin:0'},
     h('button',{class:'btn ghost',onclick:()=>openCoins(u.id,u.name,$('#t-users'))},'Saldo'),
     h('button',{class:'btn ghost',onclick:async()=>{await api('/api/admin/users/'+u.id+'/mute',{minutes:muted?0:1440});loadUsers()}},muted?'Quitar silencio':'Silenciar 24 h'),
     h('button',{class:'btn ghost',onclick:async()=>{await api('/api/admin/users/'+u.id+'/ban',{ban:!u.banned,reason:'Incumplir las normas'});loadUsers()}},u.banned?'Reactivar':'Suspender')))))}}
 async function loadChat(){const r=await api('/api/admin/chat'),ul=$('#chatList');ul.innerHTML='';
  for(const m of r.items)ul.append(h('li',{class:'card'+(m.deleted?' del':'')},h('p',{},h('b',{},m.name+': '),m.text),h('p',{class:'fine'},when(m.created)+(m.deleted?' · borrado':'')),
   m.deleted?null:h('button',{class:'btn ghost',onclick:async()=>{await api('/api/admin/chat/'+m.id+'/delete',{});loadChat()}},'Borrar')))}
 if(KEY)api('/api/admin/stats').then(start).catch(()=>{});
})();
