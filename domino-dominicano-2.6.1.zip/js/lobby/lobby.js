// Dominó Dominicano · lobby: perfil, saldo (dólares), mesas, chat, personalización, ranking, soporte.
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const h=(tag,attrs,...kids)=>{const e=document.createElement(tag);for(const k in attrs||{}){if(k==='class')e.className=attrs[k];else if(k.startsWith('on'))e.addEventListener(k.slice(2),attrs[k]);else if(attrs[k]!=null)e.setAttribute(k,attrs[k])}
 for(const c of kids.flat())if(c!=null)e.append(c.nodeType?c:document.createTextNode(String(c)));return e};
const fmt=n=>Number(n||0).toLocaleString('es-DO');
const ago=t=>{const s=(Date.now()-t)/1000;return s<60?'ahora':s<3600?Math.floor(s/60)+' min':s<86400?Math.floor(s/3600)+' h':new Date(t).toLocaleDateString('es-DO')};
const LOBBY={me:null,mode:'parejas',stake:1000,free:false,target:200,stakes:[1000,2000,4000,8000],online:false,sala:null};
try{const t=+localStorage.getItem('domino.target');if(t===100||t===200)LOBBY.target=t}catch(e){}
function toastL(txt,kind){const t=h('div',{class:'toast '+(kind||'')},txt);$('#toasts').append(t);setTimeout(()=>t.remove(),4200)}
function dialog(title,body,buttons){$('#dlgT').textContent=title;const b=$('#dlgB');b.innerHTML='';if(typeof body==='string')b.append(h('p',{},body));else if(body)b.append(body);
 const r=$('#dlgBtns');r.innerHTML='';for(const[txt,cls,fn]of buttons)r.append(h('button',{class:'btn '+cls,onclick:()=>{$('#dialog').hidden=true;fn&&fn()}},txt));$('#dialog').hidden=false}

// ---- secciones ----
function showView(v){const tab={jugar:'inicio',soporte:'perfil'}[v]||v;$$('.tabs button').forEach(b=>b.classList.toggle('on',b.dataset.v===tab));$$('.view').forEach(s=>s.hidden=s.id!=='v-'+v);
 if(v==='ranking')loadRanking();if(v==='soporte')loadTickets();if(v==='perfil')renderProfile();if(v==='inicio'&&typeof renderHome==='function')renderHome();if(v==='billetera'&&typeof loadWallet==='function')loadWallet();$('#lobby').scrollTop=0}
$$('.tabs button').forEach(b=>b.onclick=()=>showView(b.dataset.v));
document.addEventListener('click',e=>{const b=e.target.closest('[data-go]');if(!b)return;e.preventDefault();if(b.dataset.wtab&&typeof setWalletTab==='function')setWalletTab(b.dataset.wtab);showView(b.dataset.go)});
// mirar es libre; para jugar hay que registrarse (con correo, 18+)
function requireAccount(next){if(!LOBBY.online||(LOBBY.me&&LOBBY.me.registered)||(typeof CONF!=='undefined'&&CONF.playNeedsAccount===false))return next();
 const box=h('div',{class:'reg-dlg'},h('p',{},'Para jugar necesitas una cuenta. Es gratis y toma un minuto: te enviamos un código a tu correo.'),buildRegister(()=>{$('#dialog').hidden=true;next()}));
 dialog('Regístrate para jugar',box,[['Ahora no','ghost']])}

// ---- perfil y monedas ----
function setMe(me){LOBBY.me=me;try{localStorage.setItem('domino.me',JSON.stringify({name:me.name,avatar:me.avatar}))}catch(e){}
 $('#coins').textContent=money(me.coins);$('#meName').textContent=me.name;$('#meAv').src=DomProfile.dataUri(me.avatar,68);
 $('#dailyDot').hidden=!(me.daily||me.rescue);
 if(me.prefs&&JSON.stringify(me.prefs)!==JSON.stringify(PREFS)){savePrefsLocal(me.prefs);applyTheme(me.prefs,true)}
 renderStakes();if(!$('#v-perfil').hidden)renderProfile();if(typeof renderHome==='function')renderHome(true);if(!$('#v-estilo').hidden)renderThemes()}
$('#coinsBtn').onclick=async()=>{const me=LOBBY.me;if(!LOBBY.online||!me)return;
 if(me.daily){try{const r=await NET.api('/api/daily',{});toastL('¡Bono diario! +'+money(r.amount),'good')}catch(e){toastL(e.message,'bad')}return}
 if(me.rescue){try{const r=await NET.api('/api/rescue',{});toastL('Bono de rescate: +'+money(r.amount),'good')}catch(e){toastL(e.message,'bad')}return}
 toastL('Tu saldo: '+money(me.coins)+'. Las recargas y retiros llegan pronto.')};
$('#meBtn').onclick=()=>showView('perfil');

// ---- elegir mesa ----
function renderStakes(){const box=$('#stakes');box.innerHTML='';
 for(const s of LOBBY.stakes){const poor=LOBBY.online&&LOBBY.me&&LOBBY.me.coins<s;
  box.append(h('button',{class:'stake'+(s===LOBBY.stake?' on':''),role:'radio','aria-checked':s===LOBBY.stake,disabled:poor?'':null,onclick:()=>{LOBBY.stake=s;renderStakes()}},
   h('span',{class:'chip'},money(s)),h('small',{},'ganas '+money(Math.floor(s*(LOBBY.mode==='trio'?3:2)*.9)))))}
 $('#stakeBox').hidden=LOBBY.free;$$('.pay').forEach(x=>{const on=(x.dataset.free==='1')===LOBBY.free;x.classList.toggle('on',on);x.setAttribute('aria-checked',on)});
 $$('.len').forEach(x=>{const on=+x.dataset.target===LOBBY.target;x.classList.toggle('on',on);x.setAttribute('aria-checked',on)})
 $('#playBtn').disabled=!LOBBY.online;$('#salaNew').disabled=!LOBBY.online}
$$('.mode').forEach(b=>b.onclick=()=>{LOBBY.mode=b.dataset.mode;$$('.mode').forEach(x=>{x.classList.toggle('on',x===b);x.setAttribute('aria-checked',x===b)});renderStakes()});
$$('.pay').forEach(b=>b.onclick=()=>{LOBBY.free=b.dataset.free==='1';renderStakes()});
const stakeNow=()=>LOBBY.free?0:LOBBY.stake;
$$('.len').forEach(b=>b.onclick=()=>{LOBBY.target=+b.dataset.target;try{localStorage.setItem('domino.target',LOBBY.target)}catch(e){}renderStakes()});
$('#playBtn').onclick=()=>requireAccount(playNow);
function playNow(){if(!LOBBY.online)return toastL('Sin conexión con el servidor. Prueba el modo práctica.','bad');
 if(LOBBY.sala)return toastL('Estás en una sala privada. Sal de la sala para buscar mesa.','bad');
 if(stakeNow()&&!LOBBY.me.registered&&!(typeof CONF!=='undefined'&&CONF.moneyNeedsAccount===false))return dialog('Regístrate para jugar con dinero','Para jugar con dinero necesitas una cuenta con tu correo confirmado (18 años o más). Mientras tanto puedes jugar gratis.',[['Jugar gratis','ghost',()=>{LOBBY.free=true;renderStakes()}],['Registrarme','gold',()=>showView('perfil')]]);
 if(LOBBY.me.coins<stakeNow())return dialog('Saldo insuficiente','Tu saldo es '+money(LOBBY.me.coins)+'. Recarga en Billetera o juega gratis.',[['Jugar gratis','ghost',()=>{LOBBY.free=true;renderStakes()}],['Recargar','gold',()=>{setWalletTab('deposit');showView('billetera')}]]);
 NET.send({t:'queue',mode:LOBBY.mode,stake:stakeNow(),target:LOBBY.target})}
$('#cancelSearch').onclick=()=>{NET.send({t:'unqueue'});$('#searching').hidden=true};
$('#practiceBtn').onclick=()=>requireAccount(()=>enterPractice(LOBBY.mode));
const MODE_NAMES={parejas:'Parejas',duelo:'1 vs 1',trio:'Tríos'};
const lenName=t=>t===100?'rápida (a 100)':'normal (a 200)';
NET.on('queued',m=>{$('#searchTxt').textContent=MODE_NAMES[m.mode]+' · partida '+lenName(m.target)+' · '+(m.stake?'mesa de '+money(m.stake):'gratis')+(m.stake&&!m.wait?' · esperando a otras personas':'');$('#searching').hidden=false});
NET.on('unqueued',()=>{$('#searching').hidden=true});

// ---- chat ----
function chatItem(m){const mine=LOBBY.me&&m.uid===LOBBY.me.id;
 return h('li',{class:'msg','data-id':m.id},h('img',{src:DomProfile.dataUri(m.avatar,64),alt:''}),
  h('div',{},h('span',{class:'who'},m.name),h('span',{class:'when'},ago(m.ts)),mine?null:h('button',{class:'rep',title:'Reportar mensaje',onclick:()=>reportMsg(m)},'reportar'),h('p',{},m.text)))}
function addChat(m){const box=$('#msgs'),near=box.scrollHeight-box.scrollTop-box.clientHeight<80;box.append(chatItem(m));while(box.children.length>120)box.firstChild.remove();if(near)box.scrollTop=box.scrollHeight}
function reportMsg(m){dialog('Reportar mensaje','"'+m.text+'" — '+m.name,[['Cancelar','ghost'],['Reportar','gold',()=>NET.send({t:'report',id:m.id})]])}
$('#chatForm').onsubmit=e=>{e.preventDefault();const v=$('#chatIn').value.trim();if(!v)return;if(!LOBBY.online)return toastL('El chat necesita conexión con el servidor.','bad');NET.send({t:'chat',text:v});$('#chatIn').value=''};
NET.on('chat',m=>addChat(m.m));
NET.on('chatdel',m=>{const li=$('#msgs [data-id="'+m.id+'"]');if(li)li.remove()});

// ---- personalización ----
let avDraft=null;
function renderAvatar(){const o=DomProfile.parse(avDraft);$('#avBig').src=DomProfile.dataUri(avDraft,150);const box=$('#avParts');box.innerHTML='';
 for(const k of DomProfile.ORDER){const P=DomProfile.PARTS[k],opts=h('div',{class:'av-opts'});
  for(let i=0;i<P.n;i++){const preview=Object.assign({},o,{[k]:i});
   const sw=k==='s'?DomProfile.SKIN[i]:k==='c'?DomProfile.HAIR[i]:k==='k'?DomProfile.BG[i]:null;
   const b=h('button',{class:i===o[k]?'on':'',title:P.names?P.names[i]:P.label+' '+(i+1),'aria-label':P.label+': '+(P.names?P.names[i]:i+1),onclick:()=>{avDraft=DomProfile.encode(preview);renderAvatar()}});
   if(sw)b.style.background=sw;else b.append(h('img',{src:DomProfile.dataUri(DomProfile.encode(preview),34),alt:'',width:30,height:30,style:'border-radius:50%'}));
   opts.append(b)}
  box.append(h('div',{class:'av-part'},h('span',{},P.label),opts))}}
$('#avRandom').onclick=()=>{avDraft=DomProfile.random();renderAvatar()};
$('#avSave').onclick=async()=>{if(!LOBBY.online){saveLocalMe({avatar:avDraft});return toastL('Avatar guardado en este dispositivo.','good')}
 try{const r=await NET.api('/api/profile',{avatar:avDraft});setMe(r.me);toastL('Avatar guardado.','good')}catch(e){toastL(e.message,'bad')}};
const SWATCH={scene:{patio:'linear-gradient(#59c2b4 0 45%,#b4643a 45%)',ciudad:'linear-gradient(#2a2552,#e0775a 50%,#8d8a84 50%)',clasico:'radial-gradient(circle,#2d241c,#0c0805)'},felt:{bandera:'linear-gradient(90deg,#002d62 0 44%,#eee 44% 56%,#ce1126 56%)',verde:'radial-gradient(circle,#2f7a4f,#0f3a22)',azul:'radial-gradient(circle,#2c5a9a,#0e2246)',vino:'radial-gradient(circle,#7d2a35,#36090f)'},
 wood:{nogal:'repeating-linear-gradient(90deg,#a8683a 0 6px,#6b3f1e 6px 9px,#93582e 9px 15px)',caoba:'repeating-linear-gradient(90deg,#9e4228 0 6px,#561a0c 6px 9px,#82321d 9px 15px)',roble:'repeating-linear-gradient(90deg,#d4a66c 0 6px,#9a6a36 6px 9px,#c4945a 9px 15px)',ebano:'repeating-linear-gradient(90deg,#523a2c 0 6px,#1a120d 6px 9px,#3d2a20 9px 15px)'},
 tiles:{marfil:'linear-gradient(#fffdf4,#e6e1cf)',perla:'linear-gradient(#ffffff,#e3e6ea)',negro:'linear-gradient(#3a3a3d,#1b1b1d)'},
 pips:{clasico:'radial-gradient(circle at 30% 50%,#1b1b1b 0 7px,transparent 8px),radial-gradient(circle at 70% 50%,#1b1b1b 0 7px,transparent 8px),#f5ecd9',colores:'radial-gradient(circle at 20% 50%,#d62828 0 7px,transparent 8px),radial-gradient(circle at 40% 50%,#1d6fd1 0 7px,transparent 8px),radial-gradient(circle at 60% 50%,#2b9348 0 7px,transparent 8px),radial-gradient(circle at 80% 50%,#e8890c 0 7px,transparent 8px),#f5ecd9'}};
const THEME_TITLES={scene:'Ambiente',felt:'Paño',wood:'Madera',tiles:'Fichas',pips:'Puntos'};
function renderThemes(){const box=$('#themes');box.innerHTML='';
 for(const k of['scene','felt','wood','tiles','pips']){const opts=h('div',{class:'theme-opts'});
  for(const[key,label]of Object.entries(DomProfile.THEMES[k])){const price=DomProfile.priceOf(k,key),mine=DomProfile.isOwned((LOBBY.me&&LOBBY.me.owned)||[],k,key);
   opts.append(h('button',{class:'theme-opt'+(PREFS[k]===key?' on':'')+(mine?'':' locked'),onclick:()=>mine?setPref(k,key):buyItem(k,key,label,price)},h('i',{class:'sw',style:'background:'+SWATCH[k][key]}),
    h('span',{},label,h('em',{class:'tag-price'},price===0?'Gratis':mine?'Tuyo':'🔒 '+money(price)))))}
  box.append(h('div',{class:'theme-row'},h('h3',{},THEME_TITLES[k]),opts))}}
function buyItem(k,key,label,price){
 if(!LOBBY.online)return toastL('La tienda necesita conexión.','bad');
 requireAccount(()=>dialog('Comprar '+label,h('div',{},h('div',{class:'buy-sw',style:'background:'+SWATCH[k][key]}),h('p',{},'Precio: ',h('b',{},money(price)),' · Tu saldo: '+money(LOBBY.me.coins)),h('p',{class:'fine'},'Se compra una vez y es tuyo para siempre.')),
  [['Cancelar','ghost'],[LOBBY.me.coins<price?'Recargar saldo':'Comprar','gold',async()=>{if(LOBBY.me.coins<price){setWalletTab('deposit');return showView('billetera')}
   try{const r=await NET.api('/api/shop/buy',{cat:k,key});LOBBY.me=r.me;setMe(r.me);toastL('¡Listo! '+label+' ya es tuyo.','good');setPref(k,key)}catch(e){toastL(e.message,'bad')}}]]))}
function savePrefsLocal(p){try{localStorage.setItem('domino.prefs',JSON.stringify(p))}catch(e){}}
async function setPref(k,v){const p=Object.assign({},PREFS,{[k]:v});applyTheme(p,true);savePrefsLocal(PREFS);renderThemes();
 if(LOBBY.online){try{await NET.api('/api/profile',{prefs:PREFS})}catch(e){}}}
function saveLocalMe(o){const me=Object.assign({},LOBBY.me||{},o);setMe(me)}

// ---- ranking ----
let RANK_BY='wins';
$$('[data-rk]').forEach(b=>b.onclick=()=>{RANK_BY=b.dataset.rk;$$('[data-rk]').forEach(x=>x.classList.toggle('on',x===b));loadRanking()});
function rankRow(u,i){return h('li',{class:LOBBY.me&&u.id===LOBBY.me.id?'me':''},h('span',{class:'pos'},i<3?['🥇','🥈','🥉'][i]:i+1),h('img',{src:DomProfile.dataUri(u.avatar,76),alt:''}),
   h('span',{class:'nm'},u.name,h('small',{},fmt(u.games)+' partidas · '+(u.games?Math.round(100*u.wins/u.games):0)+'% ganadas')),
   RANK_BY==='money'?h('span',{class:'val'},money(u.won)):h('span',{class:'val'},fmt(u.wins),h('small',{},' ganadas')))}
async function loadRanking(){const box=$('#rank');if(!LOBBY.online){box.innerHTML='';box.append(h('li',{},'El ranking necesita conexión con el servidor.'));return}
 try{const r=await NET.api('/api/leaderboard?by='+RANK_BY);box.innerHTML='';r.items.forEach((u,i)=>box.append(rankRow(u,i)));
  if(!r.items.length)box.append(h('li',{},'Todavía nadie ha jugado. ¡Sé el primero!'));return;}catch(e){toastL(e.message,'bad')}}

// ---- soporte ----
const FAQ=[['¿Se juega con dinero?','Sí: el saldo está en dólares (US$). Puedes jugar con dinero o gratis. Para jugar con dinero necesitas una cuenta registrada con tu correo y ser mayor de 18 años. Las recargas y los retiros llegan pronto.'],
 ['¿Cuánto cobra la plataforma?','El 10% de lo que juega cada persona en cada partida con dinero. El ganador recibe el resto del pozo. Ejemplo: 1 vs 1 de $10, el pozo es $20 y el ganador recibe $18.'],
 ['¿Cómo funcionan las mesas?','Eliges el modo (Parejas, 1 vs 1 o Tríos), si la partida es rápida (a 100 puntos) o normal (a 200), y si juegas con dinero ($10, $20, $40 u $80) o gratis. Al empezar se cobra el monto a cada jugador. El que gana se lleva el pozo menos el 10%: en Parejas y 1 vs 1, 1.8 veces su monto; en Tríos, 2.7 veces.'],
 ['¿Cómo se cuentan los pases?','Pase: +25 para quien jugó si el siguiente no lleva. En Parejas solo vale si tu compañero (tu frente) sí lleva. Si nadie más lleva y tú sí: +30 y vuelves a jugar (cada vez que se repite, +30 más). Si nadie lleva, ni tú: tranque, y gana quien tenga menos puntos en la mano.'],
 ['¿Y si alguien se va en Tríos?','La partida sigue con los que quedan. Si se va alguien por el internet, tiene unos segundos para volver; si no, sale de la mesa y pierde su monto.'],
 ['¿Contra quién juego?','Contra otras personas conectadas desde cualquier lugar. Las mesas con dinero son solo entre personas. En las gratis, si en unos segundos no aparecen suficientes, la mesa se completa con jugadores de la computadora, marcados como BOT.'],
 ['¿Cómo juego con mis amigos?','En Jugar, toca "Crear sala privada e invitar". Te damos un código (ej. K7M-2QX) y un enlace: mándaselo por WhatsApp. Tus amigos abren el enlace o escriben el código en "Unirme". Cada uno elige su asiento (en parejas, los de azul van juntos contra los de rojo) y el anfitrión empieza la partida. Los asientos vacíos se llenan con BOT.'],
 ['¿Qué pasa si se me cae el internet?','Tu puesto te espera: la computadora juega por ti mientras vuelves y, al entrar otra vez, regresas a tu mesa. Si sales con el botón de salir, pierdes el monto de la mesa.'],
 ['¿Cómo guardo mi cuenta?','En Perfil, regístrate con tu correo: te llega un código de 6 números para confirmarlo. Después entras con tu correo y contraseña desde cualquier teléfono o computadora, sin perder tu saldo.'],
 ['¿Puedo jugar sin dinero?','Sí. En Jugar elige "Gratis": juegas igual contra personas o la computadora, sin apostar ni ganar nada.'],
 ['Alguien me falta el respeto en el chat','Toca "reportar" en su mensaje o escríbenos aquí con el tema "Reportar a un jugador". Revisamos todos los reportes.']];
function renderFaq(){const box=$('#faq');box.innerHTML='';for(const[q,a]of FAQ)box.append(h('details',{},h('summary',{},q),h('p',{},a)))}
async function loadTickets(){const box=$('#tickets');box.innerHTML='';if(!LOBBY.online){box.append(h('li',{class:'fine'},'Para escribirle a soporte necesitas conexión.'));return}
 try{const r=await NET.api('/api/tickets');if(!r.items.length)box.append(h('li',{class:'fine'},'Aún no tienes consultas.'));
  for(const t of r.items)box.append(h('li',{},h('button',{onclick:()=>openTicket(t.id)},h('span',{},(t.unread?'● ':'')+t.subject,h('br'),h('small',{class:'fine'},t.category+' · '+ago(t.updated))),h('span',{class:'tag '+t.status},t.status))));
  $('#supDot').hidden=!r.items.some(t=>t.unread)}catch(e){toastL(e.message,'bad')}}
async function openTicket(id){const th=$('#thread');th.hidden=false;th.innerHTML='';
 try{const r=await NET.api('/api/tickets/'+id);th.append(h('h3',{},r.ticket.subject));
  for(const m of r.messages)th.append(h('div',{class:'bubble'+(m.admin?' admin':'')},h('small',{},(m.admin?'Soporte':'Tú')+' · '+ago(m.created)),m.text));
  if(r.ticket.status!=='cerrado'){const inp=h('textarea',{rows:2,maxlength:2000,placeholder:'Responder…','aria-label':'Responder'});
   th.append(h('form',{class:'form',onsubmit:async e=>{e.preventDefault();if(!inp.value.trim())return;try{await NET.api('/api/tickets/'+id+'/messages',{text:inp.value});openTicket(id)}catch(err){toastL(err.message,'bad')}}},inp,h('button',{class:'btn gold'},'Enviar')))}
  loadTicketsQuiet()}catch(e){toastL(e.message,'bad')}}
async function loadTicketsQuiet(){try{const r=await NET.api('/api/tickets');$('#supDot').hidden=!r.items.some(t=>t.unread)}catch(e){}}
$('#ticketForm').onsubmit=async e=>{e.preventDefault();if(!LOBBY.online)return toastL('Sin conexión con el servidor.','bad');
 try{await NET.api('/api/tickets',{category:$('#tkCat').value,subject:$('#tkSubj').value,text:$('#tkText').value});$('#tkSubj').value='';$('#tkText').value='';toastL('Recibimos tu consulta. Te responderemos aquí mismo.','good');loadTickets()}catch(err){toastL(err.message,'bad')}};

// ---- registro con correo (se usa en Perfil y cuando alguien quiere jugar sin cuenta) ----
function buildRegister(onDone){const me=LOBBY.me||{};
 const n=h('input',{maxlength:16,value:me.name||'',autocomplete:'username'}),em=h('input',{type:'email',maxlength:120,autocomplete:'email',inputmode:'email',placeholder:'tucorreo@ejemplo.com'}),p=h('input',{type:'password',minlength:6,autocomplete:'new-password'});
 const codeIn=h('input',{inputmode:'numeric',maxlength:6,autocomplete:'one-time-code',placeholder:'123456',class:'otp'}),to=h('p',{class:'fine'});
 const step2=h('form',{class:'form',hidden:'',onsubmit:async e=>{e.preventDefault();try{const r=await NET.api('/api/register/verify',{code:codeIn.value});setMe(r.me);toastL('¡Correo confirmado! Tu cuenta quedó registrada.','good');onDone&&onDone()}catch(err){toastL(err.message,'bad')}}},
  to,h('label',{},'Código de 6 números',codeIn),h('div',{class:'row'},h('button',{class:'btn gold'},'Confirmar'),h('button',{type:'button',class:'btn ghost',onclick:async()=>{try{await NET.api('/api/register/resend',{});toastL('Te enviamos otro código.','good')}catch(err){toastL(err.message,'bad')}}},'Reenviar código')));
 const adult=h('input',{type:'checkbox',style:'width:auto'});
 const step1=h('form',{class:'form',onsubmit:async e=>{e.preventDefault();if(!adult.checked)return toastL('Debes tener 18 años o más.','bad');try{const r=await NET.api('/api/register',{name:n.value,email:em.value,password:p.value,adult:true});
   step1.hidden=true;step2.hidden=false;to.textContent='Te enviamos un código a '+r.email+'. Revisa también la carpeta de spam.';codeIn.focus()}catch(err){toastL(err.message,'bad')}}},
  h('label',{},'Nombre',n),h('label',{},'Correo electrónico',em),h('label',{},'Contraseña (mínimo 6)',p),h('label',{class:'check'},adult,'Tengo 18 años o más y acepto los ',h('a',{href:'/terminos',target:'_blank'},'términos')),h('button',{class:'btn gold'},'Registrarme'));
 const login=h('p',{class:'fine'},'¿Ya tienes cuenta? ',h('a',{href:'#',onclick:e=>{e.preventDefault();$('#dialog').hidden=true;showView('perfil')}},'Entra aquí'));
 return h('div',{},step1,step2,onDone?login:null)}

// ---- perfil ----
async function renderProfile(){const me=LOBBY.me;if(!me)return;
 $('#profAv').src=DomProfile.dataUri(me.avatar,84);$('#profName').textContent=me.name;
 $('#profKind').textContent=!LOBBY.online?'Sin conexión':me.registered?'Cuenta registrada'+(me.email?' · '+me.email:''):'Cuenta de invitado: regístrate con tu correo para no perder tus monedas';
 const st=$('#stats');st.innerHTML='';for(const[v,l]of[[money(me.coins),'saldo'],[fmt(me.games),'partidas'],[fmt(me.wins),'ganadas'],[me.games?Math.round(100*me.wins/me.games)+'%':'—','efectividad']])st.append(h('div',{class:'stat'},h('b',{},v),h('span',{},l)));
 $('#nameIn').value=me.name;
 const box=$('#accountBox');box.innerHTML='';
 if(LOBBY.online&&!me.registered)box.append(h('h3',{},'Registrarme con mi correo'),h('p',{class:'fine'},'Te enviamos un código para confirmar que el correo es tuyo. Para jugar debes tener 18 años o más.'),buildRegister());
 if(LOBBY.online){const n=h('input',{maxlength:16,autocomplete:'username'}),p=h('input',{type:'password',autocomplete:'current-password'});
  box.append(h('h3',{},'¿Ya tienes cuenta?'),h('form',{class:'form',onsubmit:async e=>{e.preventDefault();try{const r=await NET.api('/api/login',{name:n.value,password:p.value});NET.setToken(r.token);location.reload()}catch(err){toastL(err.message,'bad')}}},
   h('label',{},'Correo o nombre',n),h('label',{},'Contraseña',p),h('button',{class:'btn ghost'},'Entrar')));
  if(me.registered)box.append(h('div',{class:'row'},h('button',{class:'btn ghost',onclick:async()=>{try{await NET.api('/api/logout',{})}catch(e){}NET.logout();location.reload()}},'Cerrar sesión')))}
 const lg=$('#ledger');lg.innerHTML='';
 if(LOBBY.online)try{const r=await NET.api('/api/history');for(const x of r.items)lg.append(h('li',{},h('span',{},x.reason,h('br'),h('small',{class:'fine'},ago(x.created))),h('span',{class:x.delta>=0?'pos':'neg'},(x.delta>=0?'+':'')+money(x.delta))))}catch(e){}}
$('#nameForm').onsubmit=async e=>{e.preventDefault();const v=$('#nameIn').value;const err=DomProfile.checkName(v);if(err)return toastL(err,'bad');
 if(!LOBBY.online){saveLocalMe({name:v.trim()});return toastL('Nombre guardado en este dispositivo.','good')}
 try{const r=await NET.api('/api/profile',{name:v});setMe(r.me);toastL('Nombre cambiado.','good')}catch(err2){toastL(err2.message,'bad')}};

// ---- mensajes del servidor ----
NET.on('welcome',m=>{LOBBY.online=true;$('#offline').hidden=true;LOBBY.stakes=m.stakes||LOBBY.stakes;if(!LOBBY.stakes.includes(LOBBY.stake))LOBBY.stake=LOBBY.stakes[0];setMe(m.me);$('#msgs').innerHTML='';m.chat.forEach(addChat);
 const box=$('#msgs');box.scrollTop=box.scrollHeight;presence(m.presence);if(m.queue)NET.send({t:'unqueue'});loadTicketsQuiet()});
NET.on('me',m=>setMe(m.me));
NET.on('coins',m=>{if(LOBBY.me){LOBBY.me.coins=m.coins;setMe(LOBBY.me)}if(m.reason==='ajuste de soporte')toastL('Soporte ajustó tu saldo: '+(m.delta>0?'+':'')+money(m.delta),'good')});
NET.on('presence',presence);
function presence(p){if(!p)return;$('#online span').textContent=fmt(p.online)+' en línea';const g=$('#gOnline');if(g)g.textContent=fmt(p.online)}
NET.on('status',on=>{LOBBY.online=on;$('#offline').hidden=on;renderStakes()});
NET.on('error',m=>{if(m.code==='account'){$('#searching').hidden=true;return requireAccount(()=>{})}toastL(m.msg,'bad');if(m.code==='coins')$('#searching').hidden=true});
NET.on('notice',m=>{toastL(m.msg,'good');if(m.kind==='ticket')$('#supDot').hidden=false});
NET.on('banned',m=>dialog('Cuenta suspendida',m.reason||'Tu cuenta fue suspendida. Escríbenos si crees que es un error.',[['Entendido','gold']]));

function initLobby(){avDraft=(LOBBY.me&&LOBBY.me.avatar)||DomProfile.random();renderAvatar();renderThemes();renderFaq();renderStakes();if(!LOBBY.started){LOBBY.started=1;showView('inicio')}}
