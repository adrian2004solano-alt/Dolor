// Dominó Dominicano · inicio de la plataforma (juegos, saldo, mejores jugadores), billetera y descarga de la app.
const CONF={wallet:{methods:['Transferencia bancaria','PayPal'],instructions:'',depositMin:500,depositMax:50000,withdrawMin:1000,withdrawMax:100000},apkUrl:''};
async function loadConf(){try{Object.assign(CONF,await NET.api('/api/config'))}catch(e){}}
loadConf();

// ---- inicio ----
let homeRankAt=0;
function renderHome(quick){const me=LOBBY.me;if(!me)return;
 $('#hiName').textContent=me.name;$('#hiAv').src=DomProfile.dataUri(me.avatar,112);$('#hiBal').textContent=LOBBY.online?money(me.coins):'—';
 if(quick||!LOBBY.online||Date.now()-homeRankAt<20000)return;homeRankAt=Date.now();
 NET.api('/api/leaderboard?by=wins').then(r=>{const box=$('#rankMini');box.innerHTML='';
  r.items.slice(0,5).forEach((u,i)=>box.append(h('li',{class:LOBBY.me&&u.id===LOBBY.me.id?'me':''},h('span',{class:'pos'},i<3?['🥇','🥈','🥉'][i]:i+1),h('img',{src:DomProfile.dataUri(u.avatar,76),alt:''}),h('span',{class:'nm'},u.name,h('small',{},fmt(u.games)+' partidas')),h('span',{class:'val'},fmt(u.wins),h('small',{},' ganadas')))));
  if(!r.items.length)box.append(h('li',{},'Todavía nadie ha jugado. ¡Sé el primero!'))}).catch(()=>{})}
$('#gDomino').onclick=()=>showView('jugar');

// ---- billetera ----
let WT='deposit';
function setWalletTab(t){WT=t;$$('[data-wt]').forEach(b=>{b.classList.toggle('on',b.dataset.wt===t);b.setAttribute('aria-selected',b.dataset.wt===t)});renderWalletForm()}
$$('[data-wt]').forEach(b=>b.onclick=()=>setWalletTab(b.dataset.wt));
function renderWalletForm(){const w=CONF.wallet,dep=WT==='deposit';
 $('#walBal').textContent=LOBBY.me?money(LOBBY.me.coins):'—';
 const sel=$('#walMethod');sel.innerHTML='';w.methods.forEach(m=>sel.append(h('option',{value:m},m)));
 const min=dep?w.depositMin:w.withdrawMin,max=dep?w.depositMax:w.withdrawMax;
 $('#walAmt').min=min/100;$('#walAmt').max=max/100;$('#walAmt').placeholder=money(min).replace('$','')+' – '+money(max).replace('$','');
 const q=$('#walQuick');q.innerHTML='';(dep?[500,1000,2000,5000]:[1000,2500,5000]).filter(c=>c>=min&&c<=max).forEach(c=>q.append(h('button',{type:'button',onclick:()=>{$('#walAmt').value=c/100}},money(c))));
 $('#walInfo').textContent=dep?w.instructions:'Te enviamos el dinero al método que elijas cuando revisemos la solicitud. El monto se aparta de tu saldo al pedirlo; si se rechaza, vuelve a tu saldo.';
 $('#walDetL').textContent=dep?'Número de referencia del pago':'¿A dónde te lo enviamos? (cuenta, banco, correo de PayPal…)';
 $('#walGo').textContent=dep?'Enviar solicitud de recarga':'Pedir retiro';
 $('#walFine').textContent=(dep?'Recarga':'Retiro')+' entre '+money(min)+' y '+money(max)+'.'+(dep?' Un administrador confirma el pago y acredita tu saldo.':' Solo un retiro a la vez.')}
$('#walForm').onsubmit=e=>{e.preventDefault();requireAccount(async()=>{
 const amount=Math.round(parseFloat($('#walAmt').value||'0')*100);
 try{const r=await NET.api('/api/wallet/'+(WT==='deposit'?'recargar':'retirar'),{amount,method:$('#walMethod').value,details:$('#walDet').value});
  toastL(WT==='deposit'?'Recibimos tu solicitud de recarga. Te avisamos cuando se acredite.':'Pedimos tu retiro. Te avisamos cuando lo enviemos.','good');
  $('#walAmt').value='';$('#walDet').value='';loadWallet()}catch(err){toastL(err.message,'bad')}})};
const PAY_ST={pendiente:'En revisión',aprobado:'Listo',rechazado:'Rechazado'};
async function loadWallet(){renderWalletForm();const box=$('#walList');box.innerHTML='';
 if(!LOBBY.online)return box.append(h('li',{class:'fine'},'La billetera necesita conexión.'));
 if(!LOBBY.me||!LOBBY.me.registered)return box.append(h('li',{class:'fine'},'Regístrate con tu correo para recargar y retirar.'));
 try{const r=await NET.api('/api/wallet');if(!r.items.length)box.append(h('li',{class:'fine'},'Aún no tienes solicitudes.'));
  for(const x of r.items)box.append(h('li',{},h('span',{},(x.kind==='deposit'?'Recarga':'Retiro')+' · '+x.method,h('br'),h('small',{class:'fine'},ago(x.created)+(x.note?' · '+x.note:''))),
   h('span',{class:'pay-st '+x.status},(x.kind==='deposit'?'+':'−')+money(x.amount),h('small',{},PAY_ST[x.status]||x.status))))}catch(e){toastL(e.message,'bad')}}
NET.on('notice',m=>{if(m.kind==='wallet'&&!$('#v-billetera').hidden)loadWallet()});

// ---- descargar la app ----
let installEv=null;addEventListener('beforeinstallprompt',e=>{e.preventDefault();installEv=e});
$('#appBtn').onclick=async()=>{
 if(CONF.apkUrl){const a=h('a',{href:CONF.apkUrl,download:''});document.body.append(a);a.click();a.remove();return toastL('Descargando la app… Ábrela para instalarla.','good')}
 if(installEv){installEv.prompt();try{await installEv.userChoice}catch(e){}installEv=null;return}
 dialog('Instala la app',h('div',{class:'how'},h('p',{},h('b',{},'Android: '),'abre el menú ⋮ de Chrome y toca "Instalar app" o "Agregar a la pantalla principal".'),h('p',{},h('b',{},'iPhone: '),'toca Compartir (el cuadro con la flecha) y luego "Agregar a inicio".')),[['Entendido','gold']])};
