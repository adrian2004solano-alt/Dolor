// Dominó Dominicano · game/input.js
// Entrada: tocar/arrastrar fichas, ordenar la mano, botón de pase.
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global y se cargan en el orden
// definido en js/app/loader.js (no cambies ese orden sin probar).
// ---- entrada ----
const lp=e=>{let ex,ey;if(portrait){ex=e.clientY-ST;ey=IW-SR-e.clientX}else{ex=e.clientX-SL;ey=e.clientY-ST}return{x:(ex-ox)/k,y:(ey-oy)/k}};
function unlockAudio(){try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();if(AC.state==='suspended')AC.resume()}catch(e){}}
const canAct=()=>phase==='play'&&turn===0&&!pendingEnd&&!knock&&!corrido&&!H.some(i=>i.pending);
function sendPlay(it,s){it.pending={t0:now};sel=-1;drag=null;ACT({t:'play',tile:it.t.id,end:s.name})}
function nearest(t,p){let best=null,bd=1e9;for(const s of slots(t)){const q=proj(s.pl.x,s.pl.y),d=Math.hypot(p.x-q.x,p.y-q.y);if(d<bd){bd=d;best=s}}return{s:best,d:bd}}
cv.addEventListener('pointerdown',e=>{ptr=lp(e);unlockAudio();try{cv.setPointerCapture(e.pointerId)}catch(_){}
 if(phase==='pick'){if(now>=pickOpen&&got[0]<DEAL){const d=deckAt(ptr);if(d&&!d.pending){d.pending=now;d.lift=8;ACT({t:'pick',i:d.i})}}return}
 if(phase!=='play')return;
 const act=canAct();
 if(phase==='play'&&turn===0&&passBtn&&!knock&&Math.hypot(ptr.x-PB.x,ptr.y-PB.y)<PB.r+6){passBtn=null;ACT({t:'pass'});return}
 if(act&&sel>=0&&H[sel]){for(const s of slots(H[sel].t)){const q=proj(s.pl.x,s.pl.y);if(Math.hypot(ptr.x-q.x,ptr.y-q.y)<64){sendPlay(H[sel],s);return}}}
 prevSel=sel;let hit=-1;
 for(let i=H.length-1;i>=0;i--){const it=H[i];if(Math.abs(ptr.x-it.x)<HW/2+3&&Math.abs(ptr.y-it.y)<HL/2+3){hit=i;break}}
 if(hit<0){sel=-1;return}
 drag={it:H[hit],i:hit,sx:ptr.x,sy:ptr.y,moved:false};sel=hit});
cv.addEventListener('pointermove',e=>{ptr=lp(e);
 if(phase==='pick'){hoverDeck=now>=pickOpen&&got[0]<DEAL?deckAt(ptr):null;return}
 if(drag){if(Math.hypot(ptr.x-drag.sx,ptr.y-drag.sy)>8)drag.moved=true}
 else if(canAct()){hover=-1;for(let i=H.length-1;i>=0;i--){const it=H[i];if(Math.abs(ptr.x-it.x)<HW/2&&Math.abs(ptr.y-it.y)<HL/2){hover=i;break}}}});
// ordenar la mano: soltar una ficha dentro de tu tablero la coloca en ese lugar (las demás se abren para hacerle espacio)
const inRack=p=>p.y>=505&&Math.abs(p.x-CX)<340;
const rackIdx=p=>clamp(Math.round((p.x-CX)/STEP+(H.length-1)/2),0,H.length-1);
cv.addEventListener('pointerup',e=>{ptr=lp(e);if(!drag)return;const d=drag,it=d.it;drag=null;
 if(d.moved){
  if(inRack(ptr)||!canAct()){const j=rackIdx(ptr),i0=H.indexOf(it);if(i0>=0){H.splice(i0,1);H.splice(j,0,it);if(j!==i0)snd('pick')}sel=-1;return}
  const n=nearest(it.t,ptr);
  if(n.s&&(ptr.y<505||n.d<160)){sendPlay(it,n.s);return}
  if(!n.s)reject(it);sel=-1}
 else if(canAct()){if(prevSel===d.i){sel=-1}else{sel=d.i;if(!slots(it.t).length)reject(it)}}
 else sel=-1});
cv.addEventListener('pointercancel',()=>{drag=null;sel=-1});
cv.addEventListener('dblclick',e=>{if(!canAct())return;const p=lp(e);for(const it of H){if(Math.abs(p.x-it.x)<HW/2&&Math.abs(p.y-it.y)<HL/2){const s=slots(it.t);if(s.length===1)sendPlay(it,s[0]);return}}});
function reject(it){it.shake=now;toast={t0:now,txt:'Esa ficha no encaja en ninguna punta'}}
