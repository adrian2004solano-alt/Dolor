// Dominó Dominicano · render/ambient.js
// El lugar detrás de la mesa, visto de frente y DESENFOCADO (como una foto con profundidad de campo):
// un patio de barrio dominicano o la ciudad con el malecón. La mesa queda enfocada delante.
// Se pinta una vez, se desenfoca reduciéndola y ampliándola, y se reutiliza en cada cuadro.
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global.
let AMB=null;
function backdrop(){T0();const w=SW/k,h=SH/k,x0=-ox/k,y0=-oy/k;
 if(PREFS.scene==='clasico'){
  const g=c.createRadialGradient(VW/2,VH*.5,80,VW/2,VH*.5,Math.max(w,h)*.75);g.addColorStop(0,'#2d241c');g.addColorStop(1,'#0c0805');
  c.fillStyle=g;c.fillRect(x0-2,y0-2,w+4,h+4);return}
 const key=PREFS.scene+'|'+Math.round(SW)+'|'+Math.round(SH);
 if(!AMB||AMB.key!==key)AMB={key,o:paintScene(x0,y0,w,h)};
 c.drawImage(AMB.o,x0,y0,w,h)}
// pinta la escena a 1/2 de resolución y la desenfoca (reducir a 1/10 y volver a ampliar, dos pasadas)
function paintScene(x0,y0,w,h){
 const S=.5,W0=Math.ceil(w*S),H0=Math.ceil(h*S),o=document.createElement('canvas');o.width=W0;o.height=H0;
 const sv=c;c=o.getContext('2d');c.setTransform(S,0,0,S,-x0*S,-y0*S);
 try{(PREFS.scene==='ciudad'?drawCity:drawPatio)(x0,y0,w,h)}finally{c=sv}
 const blur=(src,f)=>{const a=document.createElement('canvas');a.width=Math.max(8,Math.round(W0/f));a.height=Math.max(8,Math.round(H0/f));
  const ga=a.getContext('2d');ga.imageSmoothingQuality='high';ga.drawImage(src,0,0,a.width,a.height);
  const b=document.createElement('canvas');b.width=W0;b.height=H0;const gb=b.getContext('2d');gb.imageSmoothingQuality='high';gb.drawImage(a,0,0,W0,H0);return b};
 let out=blur(blur(o,5),4);
 // un poco de luz y viñeta para que la mesa resalte
 const g=out.getContext('2d'),r=g.createRadialGradient(W0/2,H0*.48,Math.min(W0,H0)*.2,W0/2,H0*.48,Math.max(W0,H0)*.75);
 r.addColorStop(0,'rgba(0,0,0,0)');r.addColorStop(1,'rgba(0,0,0,.38)');g.fillStyle=r;g.fillRect(0,0,W0,H0);
 return out}

// ---- piezas del paisaje ----
const HZ0=380; // horizonte (detrás de la mesa)
function sky(x0,y0,w,top,bot,cols){const g=c.createLinearGradient(0,top,0,bot);cols.forEach((col,i)=>g.addColorStop(i/(cols.length-1),col));c.fillStyle=g;c.fillRect(x0-20,top,w+40,bot-top)}
function clouds(x0,w,y,n,R){for(let i=0;i<n;i++){const cx=x0+R()*w,cy=y+R()*160,s=40+R()*90;
 for(let j=0;j<7;j++){c.fillStyle='rgba(255,255,255,'+(.55+R()*.35)+')';c.beginPath();c.ellipse(cx+(R()-.5)*s*2,cy+(R()-.5)*s*.4,s*(.4+R()*.5),s*(.25+R()*.25),0,0,7);c.fill()}}}
function house(x,yb,w,h,wall,trim,R){c.fillStyle=wall;c.fillRect(x,yb-h,w,h);
 c.fillStyle='rgba(0,0,0,.12)';c.fillRect(x,yb-h,w,10);c.fillStyle=trim;c.fillRect(x-6,yb-h-8,w+12,10);
 for(let wx=x+30;wx<x+w-60;wx+=110){c.fillStyle='#f3f0e6';c.fillRect(wx-6,yb-h+40,62,72);c.fillStyle='#6b8fa8';c.fillRect(wx,yb-h+46,50,60);
  c.strokeStyle='#e8e2d2';c.lineWidth=4;for(let yy=yb-h+52;yy<yb-h+104;yy+=10){c.beginPath();c.moveTo(wx,yy);c.lineTo(wx+50,yy);c.stroke()}}
 // tinaco en el techo
 if(R()<.8){const tx=x+w*(.2+R()*.6);c.fillStyle='#1f2326';c.beginPath();c.roundRect(tx,yb-h-62,46,54,8);c.fill();c.fillStyle='#3a4045';c.fillRect(tx+4,yb-h-58,8,46)}}
function blockWall(x,yb,w,h){c.fillStyle='#9a9a94';c.fillRect(x,yb-h,w,h);c.strokeStyle='rgba(60,60,55,.5)';c.lineWidth=2;
 for(let y=yb-h;y<yb;y+=22){c.beginPath();c.moveTo(x,y);c.lineTo(x+w,y);c.stroke();for(let xx=x+((y/22)%2?0:22);xx<x+w;xx+=44){c.beginPath();c.moveTo(xx,y);c.lineTo(xx,y+22);c.stroke()}}
 c.fillStyle='rgba(30,60,20,.25)';c.fillRect(x,yb-24,w,24)}
function tree(x,yb,s,flowers,R){c.strokeStyle='#4a3424';c.lineCap='round';c.lineWidth=26*s;
 c.beginPath();c.moveTo(x,yb);c.quadraticCurveTo(x+20*s,yb-180*s,x-10*s,yb-320*s);c.stroke();
 c.lineWidth=12*s;for(const a of[-1.2,-.5,.2,.8]){c.beginPath();c.moveTo(x,yb-250*s);c.quadraticCurveTo(x+Math.cos(a)*120*s,yb-330*s,x+Math.cos(a)*240*s,yb-360*s+Math.sin(a)*60*s);c.stroke()}
 for(let i=0;i<220;i++){const a=R()*6.28,r=R()*280*s,px=x+Math.cos(a)*r*1.3,py=yb-380*s+Math.sin(a)*r*.55;
  c.fillStyle=R()<.55?['#3d6b2a','#2f5a22','#4f7f33'][Math.floor(R()*3)]:flowers[Math.floor(R()*flowers.length)];
  c.beginPath();c.ellipse(px,py,22*s+R()*20*s,14*s+R()*12*s,R()*3,0,7);c.fill()}}
function palm(x,yb,hh,R){c.strokeStyle='#6b5a44';c.lineWidth=12;c.lineCap='round';
 c.beginPath();c.moveTo(x,yb);c.quadraticCurveTo(x+40,yb-hh*.5,x+20,yb-hh);c.stroke();
 for(let i=0;i<10;i++){const a=i/10*6.28;c.strokeStyle=['#3f7a2e','#2f6224','#568e3a'][i%3];c.lineWidth=9;
  c.beginPath();c.moveTo(x+20,yb-hh);c.quadraticCurveTo(x+20+Math.cos(a)*80,yb-hh-30+Math.sin(a)*20,x+20+Math.cos(a)*150,yb-hh+40+Math.abs(Math.sin(a))*50);c.stroke()}}
function wires(x0,w,y){c.strokeStyle='rgba(30,30,30,.7)';c.lineWidth=2;for(let i=0;i<3;i++){c.beginPath();c.moveTo(x0-20,y+i*14);c.quadraticCurveTo(x0+w/2,y+i*14+50,x0+w+20,y+i*14+5);c.stroke()}}

// ================= PATIO DE BARRIO DOMINICANO (de día) =================
function drawPatio(x0,y0,w,h){const R=mulberry(11),yb=y0+h;
 sky(x0,y0,w,y0-10,HZ0,['#3d8fd6','#7cb8e8','#cfe6f5']);clouds(x0,w,y0+10,9,R);
 // casas al fondo
 house(x0+w*.02,HZ0+140,360,230,'#f2d36b','#e8e2d2',R);house(x0+w*.62,HZ0+120,320,200,'#e98a6a','#f2eee4',R);
 house(x0+w*.82,HZ0+150,380,260,'#7cc4c0','#f2eee4',R);house(x0+w*.3,HZ0+110,300,170,'#b9d58a','#f2eee4',R);
 wires(x0,w,y0+90);
 c.fillStyle='#6d5a48';c.fillRect(x0+w*.9,y0+60,14,HZ0+200-y0); // poste de luz
 // pared de blocks y verja de zinc
 blockWall(x0+w*.55,HZ0+260,w*.5,170);
 c.fillStyle='#8b8f92';c.fillRect(x0-20,HZ0+120,w*.35,150);c.strokeStyle='rgba(60,60,60,.5)';c.lineWidth=3;for(let xx=x0-20;xx<x0+w*.33;xx+=16){c.beginPath();c.moveTo(xx,HZ0+120);c.lineTo(xx,HZ0+270);c.stroke()}
 // flamboyán grande a la izquierda y otro a la derecha
 tree(x0+w*.1,HZ0+330,1.25,['#e8471f','#f26a1b','#d6301a','#f59a23'],R);
 tree(x0+w*.92,HZ0+300,.9,['#4f7f33','#3d6b2a'],R);
 // piso de tierra y cemento, con una goma vieja y matas
 const g=c.createLinearGradient(0,HZ0+250,0,yb);g.addColorStop(0,'#b99a76');g.addColorStop(1,'#8f7254');c.fillStyle=g;c.fillRect(x0-20,HZ0+250,w+40,yb-HZ0-230);
 for(let i=0;i<500;i++){c.fillStyle=R()<.5?'rgba(80,60,40,.25)':'rgba(255,240,210,.2)';c.beginPath();c.ellipse(x0+R()*w,HZ0+260+R()*(yb-HZ0-260),2+R()*8,1+R()*3,0,0,7);c.fill()}
 c.strokeStyle='#222';c.lineWidth=22;c.beginPath();c.ellipse(x0+w*.06,yb-40,60,24,0,0,7);c.stroke();
 for(const px of[x0+w*.02,x0+w*.97])for(let i=0;i<14;i++){c.strokeStyle=['#3f8a32','#2a5e22','#5aa042'][i%3];c.lineWidth=10;c.beginPath();c.moveTo(px,yb);c.quadraticCurveTo(px+(R()-.5)*120,yb-120,px+(R()-.5)*220,yb-150-R()*90);c.stroke()}}

// ================= LA CIUDAD: torres, palmas y el malecón (de día) =================
function drawCity(x0,y0,w,h){const R=mulberry(23),yb=y0+h;
 sky(x0,y0,w,y0-10,HZ0+40,['#2f7fd0','#6fb0ea','#d7ecf8']);clouds(x0,w,y0+20,7,R);
 // torres modernas
 let x=x0-40;while(x<x0+w+40){const bw=70+R()*110,bh=160+R()*360,top=HZ0+60-bh;
  const col=['#c8d3dd','#9fb3c4','#e4ddd0','#7f97ad','#d9c7a8'][Math.floor(R()*5)];c.fillStyle=col;c.fillRect(x,top,bw,bh+200);
  c.fillStyle='rgba(40,70,100,.35)';for(let yy=top+10;yy<HZ0+60;yy+=16)c.fillRect(x+6,yy,bw-12,7);
  c.fillStyle='rgba(255,255,255,.25)';c.fillRect(x,top,6,bh+200);x+=bw+10+R()*30}
 // el mar a un lado y el malecón
 const g=c.createLinearGradient(0,HZ0+60,0,HZ0+150);g.addColorStop(0,'#2f8fb8');g.addColorStop(1,'#1f6e98');c.fillStyle=g;c.fillRect(x0-20,HZ0+60,w+40,90);
 for(let i=0;i<60;i++){c.fillStyle='rgba(255,255,255,.35)';c.fillRect(x0+R()*w,HZ0+66+R()*80,10+R()*30,2)}
 c.fillStyle='#d8d2c4';c.fillRect(x0-20,HZ0+150,w+40,26);c.fillStyle='#bfb8a8';c.fillRect(x0-20,HZ0+176,w+40,10);
 // palmas del malecón
 for(let px=x0+40;px<x0+w;px+=200+R()*120)palm(px,HZ0+170,240+R()*80,R);
 // avenida con carros (manchas de color por el desenfoque)
 const ga=c.createLinearGradient(0,HZ0+186,0,yb);ga.addColorStop(0,'#5b5d61');ga.addColorStop(1,'#3d3f43');c.fillStyle=ga;c.fillRect(x0-20,HZ0+186,w+40,yb-HZ0-186);
 c.fillStyle='#f2f2ee';for(let xx=x0;xx<x0+w;xx+=90)c.fillRect(xx,HZ0+260,50,6);
 for(let i=0;i<10;i++){c.fillStyle=['#c0392b','#f2f2f2','#2e86de','#f1c40f','#222'][Math.floor(R()*5)];c.beginPath();c.roundRect(x0+R()*w,HZ0+200+R()*120,120,44,14);c.fill()}
 // acera con matas en primer plano
 c.fillStyle='#b7b1a6';c.fillRect(x0-20,yb-80,w+40,80);
 for(const px of[x0+w*.03,x0+w*.97])for(let i=0;i<14;i++){c.strokeStyle=['#3f8a32','#2a5e22','#5aa042'][i%3];c.lineWidth=10;c.beginPath();c.moveTo(px,yb);c.quadraticCurveTo(px+(R()-.5)*120,yb-120,px+(R()-.5)*220,yb-150-R()*90);c.stroke()}}
